// layout.js — shared navbar, footer, and the sidebar used by player/admin pages.
// Every page calls these through app.js, so there is exactly one copy of each.
import { routes, url } from "./paths.js";
import { esc } from "./utils.js";
import { getSession, homeFor, logout } from "./auth.js";

export const PUBLIC_NAV = [
  { key: "home", label: "Home", href: () => routes.home() },
  {
    key: "tournaments",
    label: "Tournaments",
    href: () => routes.tournaments(),
    also: ["tournament-details", "registration"],
  },
  {
    key: "matches",
    label: "Matches",
    href: () => routes.matches(),
    also: ["match-details"],
  },
  {
    key: "teams",
    label: "Teams",
    href: () => routes.teams(),
    also: ["team-details", "player-profile"],
  },
  {
    key: "leaderboard",
    label: "Leaderboard",
    href: () => routes.leaderboard(),
  },
  { key: "news", label: "News", href: () => routes.news() },
];

const brand = (href) => `
  <a class="brand" href="${href}" aria-label="Esport Hub home">
    <span class="brand-mark" aria-hidden="true"><i class="bi bi-lightning-charge-fill"></i></span>
    <span class="brand-text">ESPORT<b>HUB</b></span>
  </a>`;

export function renderNavbar(el, activeKey) {
  const s = getSession();
  const links = PUBLIC_NAV.map((n) => {
    const isActive = n.key === activeKey || n.also?.includes(activeKey);
    const activeClass = isActive ? "active" : "";
    const ariaCurrent = n.key === activeKey ? 'aria-current="page"' : "";
    return `
      <li class="nav-item">
        <a class="nav-link ${activeClass}" ${ariaCurrent} href="${n.href()}">
          ${n.label}
        </a>
      </li>`;
  }).join("");

  const auth = s
    ? `<div class="dropdown">
        <button class="btn btn-eh-outline btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="bi bi-person-fill" aria-hidden="true"></i> ${esc(s.name)}
        </button>
        <ul class="dropdown-menu dropdown-menu-end eh-dropdown">
          <li>
            <a class="dropdown-item" href="${homeFor(s.role)}">
              <i class="bi bi-speedometer2" aria-hidden="true"></i>
              ${s.role === "admin" ? "Admin panel" : "My dashboard"}
            </a>
          </li>
          <li><hr class="dropdown-divider"></li>
          <li>
            <button class="dropdown-item" data-action="logout">
              <i class="bi bi-box-arrow-right" aria-hidden="true"></i> Log out
            </button>
          </li>
        </ul>
      </div>`
    : `<a class="btn btn-link nav-login" href="${routes.login()}">Login</a>
       <a class="btn btn-eh btn-sm" href="${routes.register()}">Register</a>`;

  el.innerHTML = `
  <nav class="navbar navbar-expand-lg eh-nav" id="mainNav" aria-label="Main">
    <div class="container">
      ${brand(routes.home())}
      <button class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navMenu"
              aria-controls="navMenu"
              aria-expanded="false"
              aria-label="Toggle navigation">
        <i class="bi bi-list"></i>
      </button>
      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav mx-lg-auto">${links}</ul>
        <div class="nav-auth">${auth}</div>
      </div>
    </div>
  </nav>`;

  const nav = el.querySelector("#mainNav");
  const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 24);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
  el.querySelector('[data-action="logout"]')?.addEventListener("click", () => {
    logout();
    location.href = routes.home();
  });
}

export function renderFooter(el) {
  el.innerHTML = `
  <footer class="eh-footer">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4">
          ${brand(routes.home())}
          <p class="footer-about">
            Tournament management for BGMI and Free Fire. Register your squad,
            play your matches and climb the leaderboard.
          </p>
          <div class="social" aria-label="Social links">
            <a href="${routes.contact()}" aria-label="Contact us"><i class="bi bi-envelope-fill"></i></a>
            <a href="${routes.news()}" aria-label="News"><i class="bi bi-megaphone-fill"></i></a>
            <a href="${routes.matches()}" aria-label="Live matches"><i class="bi bi-broadcast"></i></a>
            <a href="${routes.leaderboard()}" aria-label="Leaderboard"><i class="bi bi-trophy-fill"></i></a>
          </div>
        </div>
        <div class="col-6 col-lg-2">
          <h2 class="footer-h">Navigate</h2>
          <ul>
            <li><a href="${routes.home()}">Home</a></li>
            <li><a href="${routes.matches()}">Matches</a></li>
            <li><a href="${routes.teams()}">Teams</a></li>
            <li><a href="${routes.leaderboard()}">Leaderboard</a></li>
            <li><a href="${routes.news()}">News</a></li>
          </ul>
        </div>
        <div class="col-6 col-lg-3">
          <h2 class="footer-h">Tournaments</h2>
          <ul>
            <li><a href="${routes.tournaments()}">All tournaments</a></li>
            <li><a href="${routes.registration()}">Register a team</a></li>
            <li><a href="${routes.tournaments()}?game=bgmi">BGMI</a></li>
            <li><a href="${routes.tournaments()}?game=freefire">Free Fire</a></li>
          </ul>
        </div>
        <div class="col-lg-3">
          <h2 class="footer-h">Support</h2>
          <ul>
            <li><a href="${routes.about()}">About Esport Hub</a></li>
            <li><a href="${routes.contact()}">Contact</a></li>
            <li><a href="${routes.forgot()}">Forgot password</a></li>
            <li><a href="${routes.login()}">Player login</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© ${new Date().getFullYear()} Esport Hub. Demo project — not affiliated with Krafton or Garena.</span>
        <span><a href="${routes.about()}#terms">Terms</a> · <a href="${routes.about()}#privacy">Privacy</a></span>
      </div>
    </div>
  </footer>`;
}

/* ── sidebars for the two dashboards ── */
const A = (page) => new URL(`../../Admin/${page}.html`, import.meta.url).href;
const P = (page) => url(`player/${page}.html`);
export const ADMIN_NAV = [
  {
    key: "admin-dashboard",
    label: "Dashboard",
    icon: "bi-speedometer2",
    href: A("dashboard"),
  },
  {
    key: "admin-tournaments",
    label: "Tournaments",
    icon: "bi-trophy",
    href: A("tournaments"),
  },
  {
    key: "admin-registrations",
    label: "Registrations",
    icon: "bi-clipboard-check",
    href: A("registrations"),
  },
  {
    key: "admin-matches",
    label: "Matches",
    icon: "bi-controller",
    href: A("matches"),
  },
  {
    key: "admin-scores",
    label: "Score Entry",
    icon: "bi-pencil-square",
    href: A("scores"),
  },
  {
    key: "admin-results",
    label: "Results",
    icon: "bi-flag",
    href: A("results"),
  },
  { key: "admin-teams", label: "Teams", icon: "bi-people", href: A("teams") },
  {
    key: "admin-players",
    label: "Players",
    icon: "bi-person-badge",
    href: A("players"),
  },
  {
    key: "admin-leaderboard",
    label: "Leaderboard",
    icon: "bi-bar-chart-steps",
    href: A("leaderboard"),
  },
  {
    key: "admin-users",
    label: "Users",
    icon: "bi-person-gear",
    href: A("users"),
  },
  {
    key: "admin-analytics",
    label: "Analytics",
    icon: "bi-graph-up",
    href: A("analytics"),
  },
  {
    key: "admin-announcements",
    label: "Announcements",
    icon: "bi-megaphone",
    href: A("announcements"),
  },
  {
    key: "admin-settings",
    label: "Settings",
    icon: "bi-gear",
    href: A("settings"),
  },
];
export const PLAYER_NAV = [
  {
    key: "player-dashboard",
    label: "Dashboard",
    icon: "bi-speedometer2",
    href: P("dashboard"),
  },
  {
    key: "player-tournaments",
    label: "My Tournaments",
    icon: "bi-trophy",
    href: P("tournaments"),
  },
  {
    key: "player-matches",
    label: "My Matches",
    icon: "bi-controller",
    href: P("matches"),
  },
  { key: "player-team", label: "My Team", icon: "bi-people", href: P("team") },
  {
    key: "player-achievements",
    label: "Achievements",
    icon: "bi-award",
    href: P("achievements"),
  },
  {
    key: "player-notifications",
    label: "Notifications",
    icon: "bi-bell",
    href: P("notifications"),
  },
  {
    key: "player-settings",
    label: "Profile Settings",
    icon: "bi-gear",
    href: P("settings"),
  },
];

export function renderShell({ sidebarEl, topbarEl, key, role }) {
  const items = role === "admin" ? ADMIN_NAV : PLAYER_NAV;
  const current = items.find((n) => n.key === key);
  const s = getSession();

  const navItems = items
    .map((n) => {
      const isActive = n.key === key;
      const activeClass = isActive ? "active" : "";
      const ariaCurrent = isActive ? 'aria-current="page"' : "";
      return `
        <li>
          <a class="${activeClass}" ${ariaCurrent} href="${n.href}">
            <i class="bi ${n.icon}" aria-hidden="true"></i>
            <span>${n.label}</span>
          </a>
        </li>`;
    })
    .join("");

  sidebarEl.innerHTML = `
    <div class="sidebar-brand">
      ${brand(routes.home())}
      <span class="role-tag">${role === "admin" ? "Admin" : "Player"}</span>
    </div>
    <nav aria-label="${role} navigation">
      <ul class="sidebar-nav">
        ${navItems}
      </ul>
    </nav>
    <a class="sidebar-back" href="${routes.home()}">
      <i class="bi bi-arrow-left" aria-hidden="true"></i> Back to site
    </a>`;

  topbarEl.innerHTML = `
    <button class="btn btn-eh-outline btn-sm sidebar-toggle"
            type="button"
            aria-label="Open menu"
            aria-controls="app-sidebar"
            aria-expanded="false">
      <i class="bi bi-list"></i>
    </button>
    <h1 class="topbar-title">${esc(current?.label ?? "Dashboard")}</h1>
    <div class="topbar-user">
      <span class="d-none d-sm-inline">${esc(s?.name ?? "")}</span>
      <button class="btn btn-eh-outline btn-sm" data-action="logout">
        <i class="bi bi-box-arrow-right" aria-hidden="true"></i> Log out
      </button>
    </div>`;
  const toggle = topbarEl.querySelector(".sidebar-toggle");
  const setOpen = (open) => {
    document.body.classList.toggle("sidebar-open", open);
    toggle.setAttribute("aria-expanded", String(open));
  };
  toggle.addEventListener("click", () =>
    setOpen(!document.body.classList.contains("sidebar-open")),
  );
  document
    .querySelector(".sidebar-scrim")
    ?.addEventListener("click", () => setOpen(false));
  topbarEl
    .querySelector('[data-action="logout"]')
    .addEventListener("click", () => {
      logout();
      location.href = routes.login();
    });
}
