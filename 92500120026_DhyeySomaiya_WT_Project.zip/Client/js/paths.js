// paths.js — one place that knows where the site root is.
// import.meta.url is the URL of THIS file (/js/paths.js), so "../" is the site root.
// That makes links work from /, /pages/, /player/ and /admin/ without ever counting "../".

export const ROOT = new URL("../", import.meta.url).href;

export const url = (path = "") => ROOT + String(path).replace(/^\/+/, "");

const q = (v) => encodeURIComponent(v);

export const routes = {
  home: () => url("index.html"),
  tournaments: () => url("pages/tournaments.html"),
  tournament: (id) => url(`pages/tournament-details.html?id=${q(id)}`),
  registration: (tournamentId) =>
    url(
      `pages/registration.html${tournamentId ? `?tournament=${q(tournamentId)}` : ""}`,
    ),
  matches: () => url("pages/matches.html"),
  match: (id) => url(`pages/match-details.html?id=${q(id)}`),
  leaderboard: (tournamentId) =>
    url(
      `pages/leaderboard.html${tournamentId ? `?tournament=${q(tournamentId)}` : ""}`,
    ),
  teams: () => url("pages/teams.html"),
  team: (id) => url(`pages/team-details.html?id=${q(id)}`),
  player: (id) => url(`pages/player-profile.html?id=${q(id)}`),
  news: () => url("pages/news.html"),
  about: () => url("pages/about.html"),
  contact: () => url("pages/contact.html"),
  login: (next) => url(`pages/login.html${next ? `?next=${q(next)}` : ""}`),
  register: () => url("pages/register.html"),
  forgot: () => url("pages/forgot-password.html"),
  playerHome: () => url("player/dashboard.html"),
  adminHome: () => new URL("../../Admin/dashboard.html", import.meta.url).href,
};
