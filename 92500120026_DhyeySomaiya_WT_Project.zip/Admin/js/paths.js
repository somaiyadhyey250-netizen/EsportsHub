// paths.js — Admin portal paths
export const ROOT = new URL("../", import.meta.url).href;

export const url = (path = "") => ROOT + String(path).replace(/^\/+/, "");

const q = (v) => encodeURIComponent(v);

export const routes = {
  home: () => new URL("../../Client/index.html", import.meta.url).href,
  tournaments: () => url("tournaments.html"),
  matches: () => url("matches.html"),
  teams: () => url("teams.html"),
  leaderboard: () => url("leaderboard.html"),
  login: (next) =>
    new URL(
      `../../Client/pages/login.html${next ? `?next=${q(next)}` : ""}`,
      import.meta.url,
    ).href,
  register: () =>
    new URL("../../Client/pages/register.html", import.meta.url).href,
  forgot: () =>
    new URL("../../Client/pages/forgot-password.html", import.meta.url).href,
  playerHome: () =>
    new URL("../../Client/player/dashboard.html", import.meta.url).href,
  adminHome: () => url("dashboard.html"),
};
