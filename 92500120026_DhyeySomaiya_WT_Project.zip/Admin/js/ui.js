// ui.js — reusable UI helpers: badges, logos, empty/loading states, toasts, counters, reveal-on-scroll.
import { GAMES, STATUS } from "./constants.js";
import { esc, initials } from "./utils.js";
import { url } from "./paths.js";

export const gameBadge = (gameId) => {
  const g = GAMES[gameId];
  return (
    `<span class="badge-game">` +
    `<i class="bi ${g?.icon ?? "bi-controller"}" aria-hidden="true"></i>` +
    `${esc(g?.name ?? gameId)}` +
    `</span>`
  );
};

export const statusBadge = (status) => {
  const s = STATUS[status] ?? { label: status, cls: "upcoming" };
  const liveDot =
    s.cls === "live" ? '<span class="live-dot" aria-hidden="true"></span>' : "";
  return `<span class="badge-status is-${s.cls}">${liveDot}${esc(s.label)}</span>`;
};

/** Team logo = initials on a red gradient whose hue comes from the team record (no image files needed). */
export const teamLogo = (team, size = "md") => {
  const tag = esc(team?.tag?.slice(0, 3) ?? initials(team?.name));
  const hue = Number(team?.hue) || 0;
  return `<span class="team-logo team-logo-${size}" style="--hue:${hue}" aria-hidden="true">${tag}</span>`;
};

export const playerAvatar = (player, size = "md") => {
  const name = esc(initials(player?.username?.replace("_", " ")));
  const hue = Number(player?.hue) || 0;
  return `<span class="team-logo team-logo-${size} is-round" style="--hue:${hue}" aria-hidden="true">${name}</span>`;
};

export const emptyState = (message, icon = "bi-controller", action = "") =>
  `<div class="empty-state" role="status">` +
  `<i class="bi ${icon}" aria-hidden="true"></i>` +
  `<p>${esc(message)}</p>${action}` +
  `</div>`;

export const skeletonCards = (n = 3) =>
  Array.from(
    { length: n },
    () => `<div class="skeleton-card" aria-hidden="true"></div>`,
  ).join("");

export const sectionHeader = (title, sub = "", right = "") =>
  `<div class="section-head">` +
  `<div>` +
  `<h2 class="section-title">${esc(title)}</h2>` +
  (sub ? `<p class="section-sub">${esc(sub)}</p>` : "") +
  `</div>` +
  right +
  `</div>`;

export const pageHeader = (title, sub = "", crumbs = []) => {
  const crumbsHtml = crumbs.length
    ? `<nav aria-label="Breadcrumb">
        <ol class="eh-breadcrumb">
          ${crumbs
            .map((c) =>
              c.href
                ? `<li><a href="${c.href}">${esc(c.label)}</a></li>`
                : `<li aria-current="page">${esc(c.label)}</li>`,
            )
            .join("")}
        </ol>
      </nav>`
    : "";

  return `
  <header class="page-hero">
    <div class="container">
      ${crumbsHtml}
      <h1>${esc(title)}</h1>
      ${sub ? `<p>${esc(sub)}</p>` : ""}
    </div>
  </header>`;
};

/** Resolve an asset path stored in data (e.g. "assets/images/x.svg") to a URL that works from any folder. */
export const asset = (path) => url(path);

/* ── toast (Bootstrap) ── */
export function toast(message, type = "success") {
  const host = document.getElementById("toastHost");
  if (!host || !window.bootstrap) {
    console.log(`[toast:${type}]`, message);
    return;
  }
  const icons = {
    success: "bi-check-circle-fill",
    danger: "bi-x-octagon-fill",
    warning: "bi-exclamation-triangle-fill",
    info: "bi-info-circle-fill",
  };
  const iconClass = icons[type] ?? icons.info;
  const el = document.createElement("div");
  el.className = `toast eh-toast is-${type}`;
  el.setAttribute("role", type === "danger" ? "alert" : "status");
  el.innerHTML = `
    <div class="d-flex align-items-center gap-2 p-3">
      <i class="bi ${iconClass}" aria-hidden="true"></i>
      <div class="flex-grow-1">${esc(message)}</div>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>`;
  host.appendChild(el);
  const t = new window.bootstrap.Toast(el, { delay: 3500 });
  el.addEventListener("hidden.bs.toast", () => el.remove());
  t.show();
}

/* ── count-up numbers: <span data-count="1200" data-prefix="₹"> ── */
export function animateCounters(root = document) {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const els = root.querySelectorAll("[data-count]");
  const run = (el) => {
    const target = Number(el.dataset.count) || 0;
    const fmt = (v) =>
      `${el.dataset.prefix ?? ""}${Math.round(v).toLocaleString("en-IN")}${el.dataset.suffix ?? ""}`;
    if (reduce) {
      el.textContent = fmt(target);
      return;
    }
    const start = performance.now(),
      dur = 1400;
    const step = (now) => {
      const p = Math.min(1, (now - start) / dur);
      el.textContent = fmt(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  const io = new IntersectionObserver(
    (entries) =>
      entries.forEach((e) => {
        if (e.isIntersecting) {
          run(e.target);
          io.unobserve(e.target);
        }
      }),
    { threshold: 0.4 },
  );
  els.forEach((el) => io.observe(el));
}
