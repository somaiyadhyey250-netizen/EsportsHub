// data.js — SEED data + first-run initialization.
//
//   data.js (seed) ──► initializeData() ──► localStorage ──► every page reads from storage
//
// The seed is only a starting point. After the first visit the app NEVER reads this file again
// for runtime data; admin edits go to localStorage and public/player/admin pages all read from there.
// (Use resetDemoData() to wipe localStorage and re-seed.)

import { KEYS, DATA_VERSION } from "./constants.js";
import { loadData, saveData, clearAll } from "./storage.js";
import { DEFAULT_SCORING_RULES } from "./scoring.js";
import { daysFromNow, demoHash, makeRng } from "./utils.js";

/* ───────────────────────────── TEAMS & PLAYERS ───────────────────────────── */

const HANDLES = [
  "Neon",
  "Blade",
  "Ghost",
  "Rex",
  "Zero",
  "Vyom",
  "Kabir",
  "Storm",
  "Fang",
  "Pulse",
  "Arjun",
  "Nova",
  "Raze",
  "Vikram",
  "Dev",
  "Riya",
  "Kaal",
  "Yudh",
  "Volt",
  "Hawk",
  "Cobra",
  "Smoke",
  "Flick",
  "Aman",
  "Jay",
  "Veer",
  "Ninja",
  "Titan",
  "Drift",
  "Echo",
  "Sana",
  "Kavya",
  "Agni",
  "Lunar",
  "Spark",
  "Rohan",
  "Sniper",
  "Talon",
  "Dune",
  "Blitz",
];
const ROLES = ["IGL", "Assaulter", "Support", "Sniper"];

// [name, tag, game, hue for logo]
const TEAM_DEFS = [
  ["Vortex Vipers", "VVX", "bgmi", 0],
  ["Crimson Syndicate", "CRS", "bgmi", 350],
  ["Nightfall Esports", "NFE", "bgmi", 12],
  ["Apex Predators", "APX", "bgmi", 20],
  ["Rudra Raiders", "RDR", "bgmi", 4],
  ["Bengal Blitz", "BBZ", "bgmi", 355],
  ["Thunder Strike", "TSI", "bgmi", 28],
  ["Phantom Legion", "PHL", "bgmi", 340],
  ["Steel Reapers", "STR", "bgmi", 8],
  ["Neon Samurai", "NSM", "bgmi", 358],
  ["Iron Falcons", "IFC", "bgmi", 16],
  ["Midnight Mavericks", "MMV", "bgmi", 345],
  ["Ember Wolves", "EMW", "freefire", 22],
  ["Inferno Squad", "INF", "freefire", 10],
  ["Shadow Cartel", "SHC", "freefire", 352],
  ["Blaze Brigade", "BLB", "freefire", 26],
  ["Cobra Clan", "CBC", "freefire", 6],
  ["Desert Hawks", "DSH", "freefire", 32],
  ["Venom Vault", "VNV", "freefire", 2],
  ["Solar Storm", "SLS", "freefire", 36],
];

function buildTeamsAndPlayers() {
  const teams = [];
  const players = [];
  TEAM_DEFS.forEach(([name, tag, game, hue], ti) => {
    const teamId = `t${String(ti + 1).padStart(2, "0")}`;
    const playerIds = [];
    for (let i = 0; i < 4; i++) {
      const pid = `p${String(ti * 4 + i + 1).padStart(3, "0")}`;
      playerIds.push(pid);
      players.push({
        id: pid,
        username: `${tag}_${HANDLES[(ti * 4 + i) % HANDLES.length]}`,
        gameId: String(5100000000 + (ti * 4 + i + 1) * 7919),
        teamId,
        role: ROLES[i],
        game,
        hue,
        status: "active",
        achievements:
          i === 0 && ti % 3 === 0
            ? ["Tournament MVP — Midnight Lobby Masters"]
            : [],
        joinedAt: daysFromNow(-200 + ti * 5),
      });
    }
    teams.push({
      id: teamId,
      name,
      tag,
      game,
      hue,
      captainId: playerIds[0],
      playerIds,
      status: "approved",
      about: `${name} is a ${game === "bgmi" ? "BGMI" : "Free Fire"} squad known for aggressive late-circle rotations.`,
      achievements: ti % 4 === 0 ? ["Regional Qualifier Winners"] : [],
      createdAt: daysFromNow(-240 + ti * 6),
    });
  });
  return { teams, players };
}

/* ───────────────────────────── TOURNAMENTS & MATCHES ───────────────────────────── */

const RULES = {
  bgmi: [
    "Squad format: 4 players per team. One substitute allowed.",
    "Emulators and third-party tools are banned. Mobile devices only.",
    "Teams must be in the custom room 10 minutes before each match.",
    "Teaming, stream-sniping and exploiting bugs lead to disqualification.",
    "Admin decisions on disputes are final. Submit evidence within 30 minutes of the match.",
  ],
  freefire: [
    "Squad format: 4 players per team. One substitute allowed.",
    "Emulators and modified clients are banned. Mobile devices only.",
    "Teams must join the custom room 10 minutes before each match.",
    "Teaming, hacks and exploiting glitches lead to disqualification.",
    "Admin decisions on disputes are final. Submit evidence within 30 minutes of the match.",
  ],
};
const MAPS = {
  bgmi: [
    "Erangel",
    "Miramar",
    "Sanhok",
    "Erangel",
    "Miramar",
    "Sanhok",
    "Erangel",
    "Miramar",
  ],
  freefire: [
    "Bermuda",
    "Purgatory",
    "Kalahari",
    "Bermuda",
    "Purgatory",
    "Kalahari",
    "Bermuda",
    "Purgatory",
  ],
};

// `teams` = indexes into the teams list (1-based team number). `progress` = how many matches are done / live.
const TOURNAMENT_DEFS = [
  {
    id: "tr-01",
    name: "Esport Hub Battle Cup",
    game: "bgmi",
    prize: 50000,
    matches: 4,
    max: 16,
    status: "registration_open",
    start: 10,
    end: 11,
    deadline: 6,
    teams: [1, 2, 3, 4, 5, 6, 7, 8],
    banner: 1,
    format: "Squad · Battle Royale · 4-match points league",
    description:
      "The flagship BGMI open of the season. Sixteen squads, four lobbies, one Chicken Dinner trophy and a ₹50,000 prize pool.",
  },
  {
    id: "tr-02",
    name: "Crimson Arena Showdown",
    game: "bgmi",
    prize: 150000,
    matches: 6,
    max: 12,
    status: "live",
    start: -1,
    end: 0,
    deadline: -5,
    teams: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    banner: 2,
    progress: { completed: 4, live: 1 },
    format: "Squad · Battle Royale · 6-match points league",
    description:
      "Twelve invited squads fight across six lobbies over two days. Highest total points after Match 6 takes the ₹1,50,000 prize pool.",
  },
  {
    id: "tr-03",
    name: "Free Fire Inferno League",
    game: "freefire",
    prize: 75000,
    matches: 6,
    max: 12,
    status: "registration_open",
    start: 8,
    end: 9,
    deadline: 4,
    teams: [13, 14, 15, 16, 17, 18],
    banner: 1,
    format: "Squad · Battle Royale · 6-match points league",
    description:
      "India's hottest Free Fire squads clash across Bermuda, Purgatory and Kalahari. Six matches, ₹75,000 on the line.",
  },
  {
    id: "tr-04",
    name: "Midnight Lobby Masters",
    game: "bgmi",
    prize: 25000,
    matches: 4,
    max: 20,
    status: "completed",
    start: -20,
    end: -19,
    deadline: -24,
    teams: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    banner: 3,
    progress: { completed: 4, live: 0 },
    format: "Squad · Battle Royale · 4-match points league",
    description:
      "A late-night BGMI cup that ended with a three-way fight for the top spot in the final lobby.",
  },
  {
    id: "tr-05",
    name: "Ember Cup — Free Fire",
    game: "freefire",
    prize: 40000,
    matches: 4,
    max: 12,
    status: "completed",
    start: -14,
    end: -13,
    deadline: -18,
    teams: [13, 14, 15, 16, 17, 18, 19, 20],
    banner: 2,
    progress: { completed: 4, live: 0 },
    format: "Squad · Battle Royale · 4-match points league",
    description:
      "Eight squads, four matches, and a ₹40,000 prize pool. Ember Wolves and Inferno Squad traded the lead all weekend.",
  },
  {
    id: "tr-06",
    name: "Winter Warzone Open",
    game: "bgmi",
    prize: 300000,
    matches: 8,
    max: 16,
    status: "registration_open",
    start: 30,
    end: 32,
    deadline: 24,
    teams: [1, 3, 5, 7, 9],
    banner: 3,
    format: "Squad · Battle Royale · 8-match points league",
    description:
      "The biggest BGMI open of the winter: eight matches over three days with a ₹3,00,000 prize pool.",
  },
  {
    id: "tr-07",
    name: "Diwali Dhamaka Free Fire Bash",
    game: "freefire",
    prize: 100000,
    matches: 6,
    max: 12,
    status: "upcoming",
    start: 40,
    end: 41,
    deadline: 34,
    teams: [],
    banner: 3,
    format: "Squad · Battle Royale · 6-match points league",
    description:
      "A festive Free Fire bash with a ₹1,00,000 prize pool. Registrations open soon.",
  },
  {
    id: "tr-08",
    name: "Rookie Rumble BGMI Cup",
    game: "bgmi",
    prize: 10000,
    matches: 4,
    max: 10,
    status: "registration_closed",
    start: 2,
    end: 3,
    deadline: -1,
    teams: [2, 4, 6, 8, 10, 11, 12],
    banner: 1,
    format: "Squad · Battle Royale · 4-match points league",
    description:
      "An open-entry cup for up-and-coming squads. Slots are filled and the lobby opens in two days.",
  },
  {
    id: "tr-09",
    name: "Republic Day Scrims Series",
    game: "freefire",
    prize: 20000,
    matches: 4,
    max: 12,
    status: "draft",
    start: 70,
    end: 71,
    deadline: 64,
    teams: [],
    banner: 2,
    format: "Squad · Battle Royale · 4-match points league",
    description: "Draft: practice scrims ahead of the Republic Day weekend.",
  },
];

const SLOT_TIMES = ["18:00", "19:30", "21:00"];

function buildTournamentsAndMatches(teams) {
  const tournaments = [];
  const matches = [];
  TOURNAMENT_DEFS.forEach((def, ti) => {
    const rng = makeRng(1000 + ti * 77);
    const teamIds = def.teams.map((n) => `t${String(n).padStart(2, "0")}`);
    const perDay = def.matches === 4 ? 2 : 3;
    const strength = Object.fromEntries(teamIds.map((id) => [id, rng()]));
    const matchIds = [];

    for (let i = 0; i < def.matches; i++) {
      const day = Math.floor(i / perDay);
      const date = daysFromNow(def.start + day);
      const prog = def.progress ?? { completed: 0, live: 0 };
      const status =
        i < prog.completed
          ? "completed"
          : i < prog.completed + prog.live
            ? "live"
            : def.status === "cancelled"
              ? "cancelled"
              : "upcoming";
      const id = `m-${def.id.slice(3)}-${i + 1}`;
      matchIds.push(id);

      let results = [];
      if (status === "completed" || status === "live") {
        const order = [...teamIds].sort(
          (a, b) => strength[b] + rng() * 0.9 - (strength[a] + rng() * 0.9),
        );
        results = order.map((teamId, pos) => {
          const base = ((teamIds.length - pos) / teamIds.length) * 9;
          const kills =
            status === "live"
              ? Math.floor(rng() * 5)
              : Math.max(0, Math.round(base + rng() * 5 - 1.5));
          return {
            teamId,
            placement: status === "live" ? null : pos + 1,
            kills,
            bonus: 0,
          };
        });
      }
      matches.push({
        id,
        tournamentId: def.id,
        matchNumber: i + 1,
        round: `Day ${day + 1}`,
        map: MAPS[def.game][i],
        scheduledAt: `${date}T${SLOT_TIMES[i % perDay]}`,
        status,
        teamIds,
        results,
      });
    }

    tournaments.push({
      id: def.id,
      name: def.name,
      game: def.game,
      banner: `assets/images/banner-${def.game}-${def.banner}.svg`,
      description: def.description,
      prizePool: def.prize,
      startDate: daysFromNow(def.start),
      endDate: daysFromNow(def.end),
      registrationDeadline: daysFromNow(def.deadline),
      teamSize: 4,
      maxTeams: def.max,
      numberOfMatches: def.matches,
      status: def.status,
      format: def.format,
      rules: RULES[def.game],
      prizeDistribution: [
        { place: "1st", share: 50 },
        { place: "2nd", share: 30 },
        { place: "3rd", share: 20 },
      ],
      registeredTeams: teamIds, // approved teams — kept in sync with registrations by tournaments.js
      matches: matchIds,
    });
  });
  return { tournaments, matches };
}

/* ───────────────────────────── REGISTRATIONS, USERS, NEWS ───────────────────────────── */

function buildRegistrations(tournaments, teams, players) {
  const regs = [];
  let n = 1;
  const add = (t, team, status, offset) => {
    const captain = players.find((p) => p.id === team.captainId);
    regs.push({
      id: `r-${String(n++).padStart(3, "0")}`,
      tournamentId: t.id,
      teamId: team.id,
      teamName: team.name,
      captainName: captain.username,
      email: `${captain.username.toLowerCase()}@esporthub.demo`,
      phone: `+91 90000 0${String(1000 + n * 37).slice(-4)}`,
      gameId: captain.gameId,
      members: team.playerIds.map(
        (pid) => players.find((p) => p.id === pid).username,
      ),
      status,
      registeredAt: daysFromNow(offset),
    });
  };
  tournaments.forEach((t) => {
    t.registeredTeams.forEach((tid, i) =>
      add(
        t,
        teams.find((x) => x.id === tid),
        "approved",
        -12 + (i % 6),
      ),
    );
  });
  // a few pending / rejected applications so the admin queue is not empty
  const tr = (id) => tournaments.find((t) => t.id === id);
  add(tr("tr-01"), teams[8], "pending", -2);
  add(tr("tr-01"), teams[9], "pending", -1);
  add(tr("tr-03"), teams[18], "pending", -1);
  add(tr("tr-06"), teams[1], "pending", 0);
  add(tr("tr-06"), teams[11], "rejected", -3);
  return regs;
}

function buildUsers(players) {
  const users = [
    {
      id: "u-admin",
      name: "Tournament Admin",
      email: "admin@esporthub.demo",
      role: "admin",
      passwordHash: demoHash("Admin@123"),
      playerId: null,
      status: "active",
      createdAt: daysFromNow(-300),
    },
  ];
  // captain of teams t01, t02, t03, t13
  ["t01", "t02", "t03", "t13"].forEach((tid, i) => {
    const captain = players.find((p) => p.teamId === tid && p.role === "IGL");
    users.push({
      id: `u-${String(i + 1).padStart(2, "0")}`,
      name: captain.username.replace("_", " "),
      email: `${captain.username.toLowerCase()}@esporthub.demo`,
      role: "player",
      passwordHash: demoHash("Player@123"),
      playerId: captain.id,
      status: "active",
      createdAt: daysFromNow(-150 + i * 10),
    });
  });
  return users;
}

const ANNOUNCEMENTS = [
  {
    id: "a-01",
    title: "Winter Warzone Open: ₹3,00,000 prize pool announced",
    category: "Event",
    date: daysFromNow(-3),
    status: "published",
    author: "Esport Hub Team",
    content:
      "Registrations for the Winter Warzone Open are live. Sixteen squads will play eight matches over three days. Check the rules and scoring system before you register your team.",
  },
  {
    id: "a-02",
    title: "Crimson Arena Showdown: Day 1 results are in",
    category: "Results",
    date: daysFromNow(-1),
    status: "published",
    author: "Esport Hub Team",
    content:
      "Four matches are complete and the lead is tight. Match 5 is live now and Match 6 follows later today. Follow the leaderboard for live standings.",
  },
  {
    id: "a-03",
    title: "Updated anti-cheat and device policy",
    category: "Rules",
    date: daysFromNow(-9),
    status: "published",
    author: "Admin Desk",
    content:
      "All players must now join custom rooms on mobile devices only. Emulator accounts found in any lobby will be removed from the tournament and the team's points will be voided.",
  },
  {
    id: "a-04",
    title: "Ember Cup finals: Ember Wolves lift the trophy",
    category: "Results",
    date: daysFromNow(-12),
    status: "published",
    author: "Esport Hub Team",
    content:
      "Ember Wolves closed the Ember Cup with a Chicken Dinner in Match 4 to finish ahead of Inferno Squad. Full match-by-match points are on the tournament page.",
  },
  {
    id: "a-05",
    title: "How to register your squad in under two minutes",
    category: "Guide",
    date: daysFromNow(-20),
    status: "published",
    author: "Support Desk",
    content:
      "Create a player account, open any tournament that shows Registration Open, and fill in your team name, captain details and Game ID. Admins approve entries within a day.",
  },
  {
    id: "a-06",
    title: "Diwali Dhamaka Free Fire Bash: registrations open soon",
    category: "Event",
    date: daysFromNow(-1),
    status: "published",
    author: "Esport Hub Team",
    content:
      "A festive Free Fire bash with a ₹1,00,000 prize pool is on its way. Registration dates will be announced here first.",
  },
];

/* ───────────────────────────── INITIALIZATION ───────────────────────────── */

export function buildSeed() {
  const { teams, players } = buildTeamsAndPlayers();
  const { tournaments, matches } = buildTournamentsAndMatches(teams);
  return {
    [KEYS.teams]: teams,
    [KEYS.players]: players,
    [KEYS.tournaments]: tournaments,
    [KEYS.matches]: matches,
    [KEYS.registrations]: buildRegistrations(tournaments, teams, players),
    [KEYS.users]: buildUsers(players),
    [KEYS.announcements]: ANNOUNCEMENTS,
    [KEYS.scoringRules]: DEFAULT_SCORING_RULES,
  };
}

/**
 * Seed any dataset that is MISSING from localStorage. Existing data is never overwritten,
 * so admin changes survive page reloads. Safe to call on every page load.
 */
export function initializeData() {
  let seed = null;
  let seeded = [];
  for (const key of [
    KEYS.teams,
    KEYS.players,
    KEYS.tournaments,
    KEYS.matches,
    KEYS.registrations,
    KEYS.users,
    KEYS.announcements,
    KEYS.scoringRules,
  ]) {
    if (loadData(key) === null) {
      seed ??= buildSeed();
      saveData(key, seed[key]);
      seeded.push(key);
    }
  }
  if (loadData(KEYS.meta) === null)
    saveData(KEYS.meta, {
      version: DATA_VERSION,
      seededAt: new Date().toISOString(),
    });
  return seeded; // which datasets were created this run (empty on normal visits)
}

/** Wipe everything and start from the seed again (also logs out). */
export function resetDemoData() {
  clearAll();
  return initializeData();
}
