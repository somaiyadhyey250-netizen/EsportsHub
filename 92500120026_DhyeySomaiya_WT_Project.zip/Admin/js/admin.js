// admin.js — helpers shared by the admin and player dashboards (stat cards + generic data tables).
// Phase 4 will add the CRUD forms/modals here.
import { esc } from "./utils.js";
import { emptyState } from "./ui.js";

export const statCard = ({ label, value, icon, href }) => {
  const tag = href ? "a" : "div";
  const hrefAttr = href ? `href="${href}"` : "";
  return `
  <div class="col-6 col-xl-4">
    <${tag} ${hrefAttr} class="stat-card">
      <i class="bi ${icon}" aria-hidden="true"></i>
      <b data-count="${Number(value) || 0}">0</b>
      <span>${esc(label)}</span>
    </${tag}>
  </div>`;
};

/** columns: [{ label, cell: (row) => htmlString }] — cells must escape their own text. */
export function dataTable(
  columns,
  rows,
  emptyMessage = "Nothing to show yet.",
) {
  if (!rows.length) return emptyState(emptyMessage, "bi-inbox");
  const headers = columns
    .map((c) => `<th scope="col">${esc(c.label)}</th>`)
    .join("");
  const bodyRows = rows
    .map(
      (r) =>
        `<tr>${columns.map((c) => `<td>${c.cell(r)}</td>`).join("")}</tr>`,
    )
    .join("");

  return `
    <div class="table-responsive eh-table-wrap">
      <table class="eh-table">
        <thead>
          <tr>${headers}</tr>
        </thead>
        <tbody>
          ${bodyRows}
        </tbody>
      </table>
    </div>`;
}

export const panel = (title, body, right = "") => `
  <section class="panel">
    <header class="panel-head">
      <h2>${esc(title)}</h2>
      ${right}
    </header>
    ${body}
  </section>`;
