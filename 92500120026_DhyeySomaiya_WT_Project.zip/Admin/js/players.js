// players.js — player access.
import { KEYS } from "./constants.js";
import { loadData } from "./storage.js";

export const getPlayers = () => loadData(KEYS.players, []);
export const getPlayerById = (id) =>
  getPlayers().find((p) => p.id === id) ?? null;
export const getPlayersByTeam = (teamId) =>
  getPlayers().filter((p) => p.teamId === teamId);
