// matches.js — match access + match card.
// Model note: BGMI / Free Fire matches are battle-royale LOBBIES with many teams, not 1-v-1.
// A match therefore has `teamIds` + `results[]`. Cards headline the two leading teams ("A VS B +N").
import { KEYS } from "./constants.js";
import { loadData } from "./storage.js";
import { esc, formatDateTime } from "./utils.js";
import { routes } from "./paths.js";
import { calculateMatchPoints } from "./scoring.js";
import { gameBadge, statusBadge } from "./ui.js";
import { getTournamentById } from "./tournaments.js";
import { getTeams } from "./teams.js";
import { getRulesFor } from "./leaderboard.js";

export const getMatches = () => loadData(KEYS.matches, []);
export const getMatchById = (id) =>
  getMatches().find((m) => m.id === id) ?? null;
export const getMatchesByStatus = (status) =>
  getMatches().filter((m) => m.status === status);

/** Teams in a match, ranked by points scored in THAT match (kills-only while live). */
export function getMatchStandings(match) {
  const t = getTournamentById(match.tournamentId);
  const rules = getRulesFor(t);
  const teams = Object.fromEntries(getTeams().map((x) => [x.id, x]));
  return (match.results ?? [])
    .map((r) => ({
      ...r,
      team: teams[r.teamId],
      points: calculateMatchPoints(r, rules),
    }))
    .sort((a, b) => b.points.total - a.points.total || b.kills - a.kills);
}

export function matchCard(match) {
  const t = getTournamentById(match.tournamentId);
  const standings = getMatchStandings(match);
  const teams = Object.fromEntries(getTeams().map((x) => [x.id, x]));
  const lead = standings.length
    ? standings.slice(0, 2).map((s) => s.team)
    : (match.teamIds ?? []).slice(0, 2).map((id) => teams[id]);
  const extra = Math.max(0, (match.teamIds?.length ?? 0) - 2);
  const live = match.status === "live";
  const leadLabel =
    match.status === "upcoming"
      ? "Scheduled lobby"
      : live
        ? "Leading now"
        : "Top finishers";
  return `
  <article class="m-card ${live ? "is-live" : ""}">
    <header class="m-card-head">
      <span class="m-card-tournament">${esc(t?.name ?? "Tournament")}</span>
      ${statusBadge(match.status)}
    </header>
    <p class="m-card-meta">
      ${t ? gameBadge(t.game) : ""}
      <span>Match ${match.matchNumber} · ${esc(match.round)} · ${esc(match.map)}</span>
    </p>
    <p class="m-card-lead">${leadLabel}</p>
    <div class="m-card-teams">
      <strong>${esc(lead[0]?.name ?? "TBA")}</strong>
      <span class="vs">VS</span>
      <strong>${esc(lead[1]?.name ?? "TBA")}</strong>
    </div>
    ${extra ? `<p class="m-card-extra">+${extra} more teams in the lobby</p>` : ""}
    <footer class="m-card-foot">
      <span>
        <i class="bi bi-calendar-event" aria-hidden="true"></i>
        ${formatDateTime(match.scheduledAt)}
      </span>
      <a class="btn btn-eh-outline btn-sm stretched-link" href="${routes.match(match.id)}">
        View Match
      </a>
    </footer>
  </article>`;
}
