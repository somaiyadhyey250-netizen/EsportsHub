// app.js — the single entry point loaded by EVERY page.
// 1. seed localStorage on first run  2. guard protected pages  3. draw navbar/footer/sidebar
// 4. hand over to the page module that matches <body data-page="...">
import { initializeData } from "./data.js";
import { requireRole } from "./auth.js";
import { renderNavbar, renderFooter, renderShell } from "./layout.js";

const body = document.body;
const key = body.dataset.page;
const layout = body.dataset.layout ?? "public";
const role = body.dataset.role; // set on player/admin pages

async function boot() {
  initializeData();
  if (role && !requireRole(role)) return;

  if (layout === "public") {
    renderNavbar(document.getElementById("app-navbar"), key);
    renderFooter(document.getElementById("app-footer"));
  } else {
    renderShell({
      sidebarEl: document.getElementById("app-sidebar"),
      topbarEl: document.getElementById("app-topbar"),
      key,
      role,
    });
  }

  // Page modules are loaded on demand so each page only downloads what it needs.
  const loader =
    key === "home"
      ? import("./pages/home.js")
      : layout === "public"
        ? import("./pages/public.js")
        : import("./pages/shell.js");
  try {
    const mod = await loader;
    await mod.render(key, { main: document.getElementById("main") });
  } catch (err) {
    console.error(`[app] page "${key}" failed to render`, err);
    document.getElementById("main").innerHTML = `
      <div class="container py-5">
        <div class="empty-state">
          <i class="bi bi-exclamation-triangle"></i>
          <p>This page could not load. Try refreshing, or reset demo data from Admin → Settings.</p>
        </div>
      </div>`;
  }
}

if (document.readyState === "loading")
  document.addEventListener("DOMContentLoaded", boot);
else boot();
