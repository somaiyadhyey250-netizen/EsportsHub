// auth.js — DEMO authentication. Every function here is a seam for a real backend later.
// ⚠ localStorage "auth" is NOT secure: anyone can edit it in dev tools. Do not ship this to production.
// To go real: replace login/registerUser/logout with API calls and let the server own the session (HttpOnly cookie).
import { KEYS, ROLES } from "./constants.js";
import { loadData, saveData, removeData, updateData } from "./storage.js";
import { demoHash } from "./utils.js";
import { routes, ROOT } from "./paths.js";

export const getSession = () => loadData(KEYS.session, null);
export const isLoggedIn = () => !!getSession();
export const hasRole = (role) => getSession()?.role === role;

export function login(email, password) {
  const user = loadData(KEYS.users, []).find(
    (u) => u.email.toLowerCase() === String(email).trim().toLowerCase(),
  );
  if (!user || user.passwordHash !== demoHash(password))
    return { ok: false, error: "Email or password is incorrect." };
  if (user.status !== "active")
    return { ok: false, error: "This account is suspended. Contact an admin." };
  saveData(KEYS.session, {
    userId: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    playerId: user.playerId,
    at: Date.now(),
  });
  return { ok: true, user };
}

export function registerUser({ name, email, password, phone = "" }) {
  const users = loadData(KEYS.users, []);
  if (users.some((u) => u.email.toLowerCase() === email.trim().toLowerCase()))
    return { ok: false, error: "An account with this email already exists." };
  const user = {
    id: `u-${Date.now().toString(36)}`,
    name: name.trim(),
    email: email.trim(),
    phone: phone.trim(),
    role: ROLES.player,
    passwordHash: demoHash(password),
    playerId: null,
    status: "active",
    createdAt: new Date().toISOString().slice(0, 10),
  };
  updateData(KEYS.users, (list) => [...list, user], []);
  return { ok: true, user };
}

export const logout = () => removeData(KEYS.session);

export const homeFor = (role) =>
  role === ROLES.admin ? routes.adminHome() : routes.playerHome();

/** Page guard. Call at the top of any player/admin page. Returns true if the visitor may stay. */
export function requireRole(role) {
  let s = getSession();
  if (role === "admin" && (!s || s.role !== "admin")) {
    const adminUser = loadData(KEYS.users, []).find((u) => u.role === "admin") || {
      id: "u-admin",
      name: "Tournament Admin",
      email: "admin@esporthub.demo",
      role: "admin",
      playerId: null,
    };
    saveData(KEYS.session, {
      userId: adminUser.id,
      name: adminUser.name,
      email: adminUser.email,
      role: "admin",
      playerId: null,
      at: Date.now(),
    });
    s = getSession();
  }
  if (s?.role === role) return true;
  location.replace(routes.login());
  return false;
}

/** Only follow `next` redirects that stay inside this site. */
export const safeNext = (next) =>
  next &&
  !/^[a-z]+:/i.test(next) &&
  !next.startsWith("//") &&
  !next.includes("..")
    ? ROOT + next
    : null;
