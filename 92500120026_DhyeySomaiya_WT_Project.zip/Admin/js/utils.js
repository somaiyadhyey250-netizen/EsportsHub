// utils.js — small pure helpers (no DOM, no storage).

const HTML_ESCAPES = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};
/** Escape text before putting it inside an HTML template string. Data comes from localStorage, so never trust it. */
export const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);

export const formatCurrency = (n) =>
  "₹" + Number(n || 0).toLocaleString("en-IN");

export function formatDate(
  iso,
  opts = { day: "numeric", month: "short", year: "numeric" },
) {
  if (!iso) return "TBA";
  const d = new Date(iso.length === 10 ? iso + "T00:00:00" : iso);
  return isNaN(d) ? "TBA" : d.toLocaleDateString("en-IN", opts);
}

export function formatDateTime(iso) {
  if (!iso) return "TBA";
  const d = new Date(iso);
  if (isNaN(d)) return "TBA";
  return d.toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

/** Local-time YYYY-MM-DD, `n` days from today. */
export function daysFromNow(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  const p = (x) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export const initials = (name) =>
  String(name || "?")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();

export const debounce = (fn, ms = 200) => {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
};

export const getParam = (name) =>
  new URLSearchParams(location.search).get(name);

/**
 * DEMO ONLY. A tiny non-cryptographic hash so demo passwords aren't stored as plain text.
 * This is NOT secure. A real backend must hash with bcrypt/argon2 on the server.
 */
export function demoHash(text) {
  let h = 5381;
  for (const ch of String(text)) h = ((h << 5) + h + ch.codePointAt(0)) >>> 0;
  return "demo$" + h.toString(16);
}

/** Seeded random numbers so demo data is the same every time it is generated. */
export function makeRng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
