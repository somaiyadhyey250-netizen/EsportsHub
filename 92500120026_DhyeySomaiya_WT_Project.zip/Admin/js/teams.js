// teams.js — team access, team stats (derived from match results) and team cards.
import { KEYS } from "./constants.js";
import { loadData } from "./storage.js";
import { esc } from "./utils.js";
import { routes } from "./paths.js";
import { gameBadge, teamLogo } from "./ui.js";
import { getTournaments } from "./tournaments.js";
import { getMatches } from "./matches.js";
import { getRulesFor } from "./leaderboard.js";
import { calculateTournamentPoints } from "./scoring.js";

export const getTeams = () => loadData(KEYS.teams, []);
export const getTeamById = (id) => getTeams().find((t) => t.id === id) ?? null;
export const getTeamPlayers = (team) => {
  const players = loadData(KEYS.players, []);
  return (team?.playerIds ?? [])
    .map((id) => players.find((p) => p.id === id))
    .filter(Boolean);
};

/** Lifetime stats for a team = sum over every tournament it played (each tournament uses its own rules). */
export function getTeamStats(teamId) {
  const totals = { matches: 0, wins: 0, kills: 0, points: 0, tournaments: 0 };
  for (const t of getTournaments()) {
    const done = getMatches().filter(
      (m) => m.tournamentId === t.id && m.status === "completed",
    );
    const s = calculateTournamentPoints(teamId, done, getRulesFor(t));
    if (!s.matches) continue;
    totals.tournaments += 1;
    totals.matches += s.matches;
    totals.wins += s.wins;
    totals.kills += s.kills;
    totals.points += s.total;
  }
  return totals;
}

export function getTopTeams(n = 4) {
  return getTeams()
    .filter((t) => t.status === "approved")
    .map((t) => ({ team: t, stats: getTeamStats(t.id) }))
    .sort((a, b) => b.stats.points - a.stats.points)
    .slice(0, n);
}

export const teamCard = (team, stats = getTeamStats(team.id)) => {
  const captain = loadData(KEYS.players, []).find(
    (p) => p.id === team.captainId,
  );
  return `
  <article class="team-card">
    ${teamLogo(team, "lg")}
    <div class="team-card-info">
      ${gameBadge(team.game)}
      <h3>
        <a href="${routes.team(team.id)}" class="stretched-link">${esc(team.name)}</a>
      </h3>
      <p class="muted">
        Captain: ${esc(captain?.username ?? "—")} · ${team.playerIds.length} members
      </p>
    </div>
    <dl class="team-card-stats">
      <div>
        <dt>Wins</dt>
        <dd>${stats.wins}</dd>
      </div>
      <div>
        <dt>Matches</dt>
        <dd>${stats.matches}</dd>
      </div>
      <div>
        <dt>Points</dt>
        <dd class="text-red">${stats.points}</dd>
      </div>
    </dl>
  </article>`;
};
