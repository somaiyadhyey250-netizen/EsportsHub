// storage.js — the ONLY file that touches localStorage directly.
// Everything else calls loadData / saveData / updateData / removeData.

const PREFIX = "esporthub_";

/** Read a value. Returns `fallback` if missing or if the stored JSON is corrupted. */
export function loadData(key, fallback = null) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

/** Write a value. Returns true on success (false if storage is full/blocked). */
export function saveData(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.error(`[storage] could not save "${key}"`, err);
    return false;
  }
}

/** Read → change → write in one step. `updater` receives the current value and returns the new one. */
export function updateData(key, updater, fallback = null) {
  const next = updater(loadData(key, fallback));
  saveData(key, next);
  return next;
}

export function removeData(key) {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

export const hasData = (key) => loadData(key, undefined) !== undefined;

/** Remove every EsportHub key (used by "Reset demo data"). */
export function clearAll() {
  try {
    Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX))
      .forEach((k) => localStorage.removeItem(k));
  } catch {
    /* ignore */
  }
}
