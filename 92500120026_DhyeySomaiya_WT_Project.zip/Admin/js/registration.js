// registration.js — tournament registrations (storage access only; the form UI lands in Phase 2).
import { KEYS } from "./constants.js";
import { loadData, updateData } from "./storage.js";

export const getRegistrations = () => loadData(KEYS.registrations, []);
export const getRegistrationsForTournament = (tid) =>
  getRegistrations().filter((r) => r.tournamentId === tid);
export const hasRegistered = (tournamentId, teamName) =>
  getRegistrations().some(
    (r) =>
      r.tournamentId === tournamentId &&
      r.teamName.toLowerCase() === teamName.trim().toLowerCase() &&
      r.status !== "rejected",
  );

export function addRegistration(reg) {
  const id = `r-${Date.now().toString(36)}`;
  const record = {
    id,
    status: "pending",
    registeredAt: new Date().toISOString().slice(0, 10),
    ...reg,
  };
  updateData(KEYS.registrations, (list) => [...list, record], []);
  return record;
}
