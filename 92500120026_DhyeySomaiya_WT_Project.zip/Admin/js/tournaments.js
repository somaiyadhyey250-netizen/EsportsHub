// tournaments.js — read/write tournaments (via storage) + the tournament card components.
import { KEYS } from "./constants.js";
import { loadData, saveData } from "./storage.js";
import { esc, formatCurrency, formatDate } from "./utils.js";
import { routes } from "./paths.js";
import { asset, gameBadge, statusBadge } from "./ui.js";

/* ── data access ── */
export const getTournaments = () => loadData(KEYS.tournaments, []);
/** Public pages never show drafts. */
export const getPublicTournaments = () =>
  getTournaments().filter((t) => t.status !== "draft");
export const getTournamentById = (id) =>
  getTournaments().find((t) => t.id === id) ?? null;

/** Insert or replace a tournament (admin create/edit). */
export function saveTournament(tournament) {
  const list = getTournaments();
  const i = list.findIndex((t) => t.id === tournament.id);
  if (i >= 0) list[i] = tournament;
  else list.push(tournament);
  saveData(KEYS.tournaments, list);
  return tournament;
}

export function deleteTournament(id) {
  saveData(
    KEYS.tournaments,
    getTournaments().filter((t) => t.id !== id),
  );
}

/** Rebuild `registeredTeams` from approved registrations (call after approve/reject/delete). */
export function syncRegisteredTeams(tournamentId) {
  const approved = loadData(KEYS.registrations, [])
    .filter((r) => r.tournamentId === tournamentId && r.status === "approved")
    .map((r) => r.teamId);
  const t = getTournamentById(tournamentId);
  if (t) saveTournament({ ...t, registeredTeams: [...new Set(approved)] });
}

/* ── filtering / sorting (used by home + tournaments page) ── */
export const isUpcoming = (t) =>
  ["upcoming", "registration_open", "registration_closed"].includes(t.status);

export function filterTournaments(
  list,
  { search = "", game = "all", status = "all", sort = "date_asc" } = {},
) {
  const q = search.trim().toLowerCase();
  const out = list.filter(
    (t) =>
      (!q ||
        t.name.toLowerCase().includes(q) ||
        t.game.toLowerCase().includes(q)) &&
      (game === "all" || t.game === game) &&
      (status === "all" ||
        (status === "upcoming_group" ? isUpcoming(t) : t.status === status)),
  );
  const sorters = {
    date_asc: (a, b) => a.startDate.localeCompare(b.startDate),
    date_desc: (a, b) => b.startDate.localeCompare(a.startDate),
    prize_desc: (a, b) => b.prizePool - a.prizePool,
    prize_asc: (a, b) => a.prizePool - b.prizePool,
  };
  return out.sort(sorters[sort] ?? sorters.date_asc);
}

/** What the register button should say/do for a tournament. */
export function registrationState(t) {
  const full = t.registeredTeams.length >= t.maxTeams;
  switch (t.status) {
    case "registration_open":
      return full
        ? { label: "Slots Full", enabled: false }
        : { label: "Register Now", enabled: true };
    case "registration_closed":
      return { label: "Registration Closed", enabled: false };
    case "live":
      return { label: "Tournament Live", enabled: false };
    case "completed":
      return { label: "Tournament Completed", enabled: false };
    case "cancelled":
      return { label: "Tournament Cancelled", enabled: false };
    case "upcoming":
      return { label: "Registration Opens Soon", enabled: false };
    default:
      return { label: "Not Published", enabled: false };
  }
}

/* ── components ── */
const banner = (t) =>
  `<img src="${asset(t.banner)}" alt="" loading="lazy" decoding="async" width="640" height="360">`;
const slots = (t) => `${t.registeredTeams.length} / ${t.maxTeams}`;

/** Standard grid card. */
export const tournamentCard = (t) => `
  <article class="t-card" data-id="${esc(t.id)}">
    <a class="t-card-banner"
       href="${routes.tournament(t.id)}"
       tabindex="-1"
       aria-hidden="true">
      ${banner(t)}
      <span class="t-card-status">${statusBadge(t.status)}</span>
    </a>
    <div class="t-card-body">
      ${gameBadge(t.game)}
      <h3 class="t-card-title">
        <a href="${routes.tournament(t.id)}" class="stretched-link">${esc(t.name)}</a>
      </h3>
      <dl class="t-card-stats">
        <div>
          <dt>Prize Pool</dt>
          <dd class="text-red">${formatCurrency(t.prizePool)}</dd>
        </div>
        <div>
          <dt>Teams</dt>
          <dd>${slots(t)}</dd>
        </div>
        <div>
          <dt>Matches</dt>
          <dd>${t.numberOfMatches}</dd>
        </div>
        <div>
          <dt>Starts</dt>
          <dd>${formatDate(t.startDate, { day: "numeric", month: "short" })}</dd>
        </div>
      </dl>
      <p class="t-card-deadline">
        <i class="bi bi-clock" aria-hidden="true"></i>
        Registration closes ${formatDate(t.registrationDeadline)}
      </p>
    </div>
  </article>`;

/** Wider card used in the moving carousel. */
export const carouselCard = (t) => `
  <a class="f-card"
     href="${routes.tournament(t.id)}"
     aria-label="${esc(t.name)} — view tournament">
    <span class="f-card-art">${banner(t)}</span>
    <span class="f-card-top">
      ${gameBadge(t.game)}
      ${statusBadge(t.status)}
    </span>
    <span class="f-card-main">
      <strong class="f-card-title">${esc(t.name)}</strong>
      <span class="f-card-grid">
        <span>
          <small>Prize Pool</small>
          <b>${formatCurrency(t.prizePool)}</b>
        </span>
        <span>
          <small>Teams</small>
          <b>${slots(t)}</b>
        </span>
        <span>
          <small>Matches</small>
          <b>${t.numberOfMatches}</b>
        </span>
      </span>
      <span class="f-card-cta">
        View Tournament <i class="bi bi-arrow-right" aria-hidden="true"></i>
      </span>
    </span>
  </a>`;
