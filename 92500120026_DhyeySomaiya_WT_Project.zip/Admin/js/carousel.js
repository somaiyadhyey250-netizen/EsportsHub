// carousel.js — auto-scrolling, swipeable, loopable card strip.
// Cards are rendered once by the caller; this file clones them once for a seamless loop.
// Motion is requestAnimationFrame + scrollLeft, so touch-swipe and the arrow buttons work natively.

export function initCarousel(root, { speed = 42 } = {}) {
  const track = root.querySelector(".carousel-track");
  if (!track || !track.children.length) return;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const originals = [...track.children];
  const count = originals.length;

  // Clone for the loop. Clones stay clickable but are hidden from screen readers and tab order.
  originals.forEach((el) => {
    const c = el.cloneNode(true);
    c.setAttribute("aria-hidden", "true");
    c.querySelectorAll("a,button").forEach((x) =>
      x.setAttribute("tabindex", "-1"),
    );
    track.appendChild(c);
  });

  let loopW = 0,
    pos = 0,
    hover = false,
    resumeAt = 0,
    visible = true,
    last = performance.now();
  const measure = () => {
    loopW = track.children[count].offsetLeft - track.children[0].offsetLeft;
  };
  measure();
  new ResizeObserver(measure).observe(track);

  const step = () =>
    Math.round(originals[0].getBoundingClientRect().width + 20);
  const pauseFor = (ms) => {
    resumeAt = performance.now() + ms;
  };

  function tick(now) {
    const dt = Math.min(now - last, 50);
    last = now;
    if (!hover && visible && !reduce && now >= resumeAt && loopW > 0) {
      pos += (speed * dt) / 1000;
      if (pos >= loopW) pos -= loopW;
      track.scrollLeft = pos;
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  // Keep our position in sync when the user swipes/scrolls, and wrap at both ends.
  track.addEventListener(
    "scroll",
    () => {
      let sl = track.scrollLeft;
      if (loopW > 0 && sl >= loopW) {
        track.scrollLeft = sl - loopW;
        sl -= loopW;
      } else if (loopW > 0 && sl <= 0 && performance.now() < resumeAt) {
        track.scrollLeft = sl + loopW;
        sl += loopW;
      }
      if (Math.abs(sl - pos) > 2) pos = sl;
    },
    { passive: true },
  );

  root.addEventListener("mouseenter", () => (hover = true));
  root.addEventListener("mouseleave", () => {
    hover = false;
    pauseFor(600);
  });
  root.addEventListener("focusin", () => (hover = true));
  root.addEventListener("focusout", () => {
    hover = false;
  });
  ["touchstart", "pointerdown", "wheel"].forEach((ev) =>
    track.addEventListener(ev, () => pauseFor(2500), { passive: true }),
  );

  new IntersectionObserver(([e]) => (visible = e.isIntersecting), {
    threshold: 0.05,
  }).observe(root);

  root.querySelectorAll("[data-dir]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const dir = btn.dataset.dir === "next" ? 1 : -1;
      pauseFor(2500);
      if (dir < 0 && track.scrollLeft < step()) track.scrollLeft += loopW; // jump forward one loop, then scroll back
      track.scrollBy({
        left: dir * step(),
        behavior: reduce ? "auto" : "smooth",
      });
    }),
  );
}
