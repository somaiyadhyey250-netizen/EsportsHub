// leaderboard.js — builds ranked tables from match results. Points maths lives in scoring.js.
import { KEYS } from "./constants.js";
import { loadData } from "./storage.js";
import { esc } from "./utils.js";
import { routes } from "./paths.js";
import { DEFAULT_SCORING_RULES, generateLeaderboard } from "./scoring.js";
import { getTournaments, getTournamentById } from "./tournaments.js";
import { getMatches } from "./matches.js";
import { getTeams } from "./teams.js";
import { teamLogo } from "./ui.js";

/** Global rules from storage, with an optional per-tournament override. */
export const getRulesFor = (tournament) => ({
  ...DEFAULT_SCORING_RULES,
  ...loadData(KEYS.scoringRules, {}),
  ...(tournament?.scoringRules ?? {}),
});

/** Only COMPLETED matches count toward standings (a live match has no placements yet). */
export function getLeaderboard(tournamentId) {
  const t = getTournamentById(tournamentId);
  if (!t) return [];
  const done = getMatches().filter(
    (m) => m.tournamentId === tournamentId && m.status === "completed",
  );
  const teamsById = Object.fromEntries(getTeams().map((x) => [x.id, x]));
  return generateLeaderboard(done, t.registeredTeams, getRulesFor(t)).map(
    (row) => ({ ...row, team: teamsById[row.teamId] }),
  );
}

/** The tournament whose standings the home page previews: a live one, else the most recent completed one. */
export function getFeaturedLeaderboardTournament() {
  const all = getTournaments();
  return (
    all.find((t) => t.status === "live") ??
    [...all]
      .filter((t) => t.status === "completed")
      .sort((a, b) => b.endDate.localeCompare(a.endDate))[0] ??
    null
  );
}

export function leaderboardTable(rows, { full = false } = {}) {
  if (!rows.length) return "";
  const head = full
    ? [
        "Rank",
        "Team",
        "Matches",
        "Wins",
        "Kills",
        "Placement Pts",
        "Kill Pts",
        "Bonus",
        "Total",
      ]
    : ["Rank", "Team", "Matches", "Wins", "Kills", "Points"];
  const body = rows
    .map(
      (r) => `
    <tr class="${r.rank <= 3 ? `rank-top rank-${r.rank}` : ""}">
      <td><span class="rank-pill">${r.rank}</span></td>
      <td>
        <a class="team-cell" href="${routes.team(r.teamId)}">
          ${teamLogo(r.team, "sm")}
          <span>${esc(r.team?.name ?? r.teamId)}</span>
        </a>
      </td>
      <td>${r.matches}</td>
      <td>${r.wins}</td>
      <td>${r.kills}</td>
      ${full ? `<td>${r.placementPoints}</td><td>${r.killPoints}</td><td>${r.bonus}</td>` : ""}
      <td class="fw-bold text-red">${r.total}</td>
    </tr>`,
    )
    .join("");

  const headerCells = head.map((h) => `<th scope="col">${h}</th>`).join("");
  return `
    <div class="table-responsive eh-table-wrap">
      <table class="eh-table">
        <thead>
          <tr>${headerCells}</tr>
        </thead>
        <tbody>
          ${body}
        </tbody>
      </table>
    </div>`;
}
