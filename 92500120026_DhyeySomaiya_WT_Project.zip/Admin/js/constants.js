// constants.js — shared names/labels. Change a label here and every page updates.

export const KEYS = {
  users: "users",
  tournaments: "tournaments",
  teams: "teams",
  players: "players",
  matches: "matches",
  registrations: "registrations",
  announcements: "announcements",
  scoringRules: "scoringRules",
  session: "session",
  meta: "meta",
};

// Bump when the seed data shape changes (see initializeData in data.js).
export const DATA_VERSION = 1;

export const GAMES = {
  bgmi: {
    id: "bgmi",
    name: "BGMI",
    fullName: "BGMI / PUBG Mobile",
    art: "assets/games/bgmi.svg",
    icon: "bi-crosshair",
    tagline: "Squad battle royale on Erangel, Miramar and Sanhok.",
  },
  freefire: {
    id: "freefire",
    name: "Free Fire",
    fullName: "Garena Free Fire",
    art: "assets/games/freefire.svg",
    icon: "bi-fire",
    tagline: "Fast 10-minute drops on Bermuda, Purgatory and Kalahari.",
  },
};

// status key -> label + CSS modifier (see .badge-status in style.css)
export const STATUS = {
  draft: { label: "Draft", cls: "draft" },
  upcoming: { label: "Upcoming", cls: "upcoming" },
  registration_open: { label: "Registration Open", cls: "open" },
  registration_closed: { label: "Registration Closed", cls: "closed" },
  live: { label: "Live", cls: "live" },
  completed: { label: "Completed", cls: "completed" },
  cancelled: { label: "Cancelled", cls: "cancelled" },
};

export const ROLES = { player: "player", admin: "admin" };
