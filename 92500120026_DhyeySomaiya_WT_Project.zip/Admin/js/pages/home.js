// pages/home.js — fills the data-driven sections of index.html. Hero + CTA markup is static in the HTML.
import { GAMES } from "../constants.js";
import { routes } from "../paths.js";
import { esc } from "../utils.js";
import { animateCounters, asset, emptyState, teamLogo } from "../ui.js";
import { initCarousel } from "../carousel.js";
import {
  filterTournaments,
  carouselCard,
  getPublicTournaments,
  tournamentCard,
} from "../tournaments.js";
import { getMatches, matchCard } from "../matches.js";
import { getTeams, getTopTeams } from "../teams.js";
import {
  getFeaturedLeaderboardTournament,
  getLeaderboard,
  leaderboardTable,
} from "../leaderboard.js";

const $ = (id) => document.getElementById(id);

const STEPS = [
  {
    icon: "bi-person-plus-fill",
    title: "Create Account",
    text: "Sign up as a player in under a minute.",
  },
  {
    icon: "bi-clipboard-check-fill",
    title: "Join Tournament",
    text: "Pick an open event and register your squad.",
  },
  {
    icon: "bi-controller",
    title: "Compete",
    text: "Drop into the custom room at match time.",
  },
  {
    icon: "bi-stars",
    title: "Earn Points",
    text: "Placement, kills and bonuses add up every match.",
  },
  {
    icon: "bi-graph-up-arrow",
    title: "Climb Rankings",
    text: "Your total decides your leaderboard rank.",
  },
];

// chip → filter options for the "Upcoming tournaments" section
const CHIPS = [
  { id: "all", label: "All", opts: {} },
  { id: "bgmi", label: "BGMI", opts: { game: "bgmi" } },
  { id: "freefire", label: "Free Fire", opts: { game: "freefire" } },
  { id: "upcoming", label: "Upcoming", opts: { status: "upcoming_group" } },
  {
    id: "open",
    label: "Registration Open",
    opts: { status: "registration_open" },
  },
];

export function render() {
  const tournaments = getPublicTournaments();
  renderHeroStats(tournaments);
  renderFeatured(tournaments);
  renderLive();
  renderUpcoming(tournaments);
  renderGames(tournaments);
  renderLeaderboard();
  renderTopTeams();
  $("steps").innerHTML = STEPS.map(
    (s, i) => `
      <li class="step">
        <span class="step-num">${i + 1}</span>
        <i class="bi ${s.icon}" aria-hidden="true"></i>
        <h3>${s.title}</h3>
        <p>${s.text}</p>
      </li>`,
  ).join("");
  observeReveal();
}

function renderHeroStats(list) {
  const active = list.filter((t) =>
    ["registration_open", "live", "registration_closed"].includes(t.status),
  ).length;
  const prize = list
    .filter((t) => t.status !== "cancelled")
    .reduce((sum, t) => sum + t.prizePool, 0);
  const played = getMatches().filter((m) => m.status === "completed").length;
  $("hero-stats").innerHTML = [
    ["Active tournaments", active, ""],
    ["Teams competing", getTeams().length, ""],
    ["Matches played", played, ""],
    ["Prize pools", prize, "₹"],
  ]
    .map(
      ([label, n, prefix]) =>
        `<div class="hero-stat"><b data-count="${n}" data-prefix="${prefix}">0</b><span>${label}</span></div>`,
    )
    .join("");
  animateCounters($("hero-stats"));
}

function renderFeatured(list) {
  const featured = list
    .filter((t) =>
      ["live", "registration_open", "upcoming", "registration_closed"].includes(
        t.status,
      ),
    )
    .sort((a, b) => b.prizePool - a.prizePool)
    .slice(0, 8);
  const root = $("featured");
  if (!featured.length) {
    root.innerHTML = emptyState(
      "No featured tournaments right now.",
      "bi-trophy",
    );
    return;
  }
  $("featured-track").innerHTML = featured.map(carouselCard).join("");
  initCarousel(root);
}

function renderLive() {
  const live = getMatches().filter((m) => m.status === "live");
  $("live-grid").innerHTML = live.length
    ? live.map(matchCard).join("")
    : emptyState(
        "No live matches currently. Check the schedule for what's next.",
        "bi-broadcast",
        `<a class="btn btn-eh-outline btn-sm" href="${routes.matches()}">See all matches</a>`,
      );
}

function renderUpcoming(list) {
  const grid = $("upcoming-grid");
  const draw = (chipId) => {
    const chip = CHIPS.find((c) => c.id === chipId);
    let rows = filterTournaments(list, { ...chip.opts, sort: "date_asc" });
    if (chipId === "all") rows = rows.filter((t) => t.status !== "cancelled");
    rows = rows.slice(0, 6);
    grid.innerHTML = rows.length
      ? rows
          .map(
            (t) => `<div class="col-md-6 col-xl-4">${tournamentCard(t)}</div>`,
          )
          .join("")
      : `<div class="col-12">${emptyState("No tournaments match this filter.", "bi-trophy")}</div>`;
  };
  $("upcoming-chips").innerHTML = CHIPS.map((c, i) => {
    const activeClass = i === 0 ? "active" : "";
    const isPressed = i === 0;
    return `
      <button type="button"
              class="chip ${activeClass}"
              data-chip="${c.id}"
              aria-pressed="${isPressed}">
        ${c.label}
      </button>`;
  }).join("");
  $("upcoming-chips").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-chip]");
    if (!btn) return;
    $("upcoming-chips")
      .querySelectorAll(".chip")
      .forEach((c) => {
        const on = c === btn;
        c.classList.toggle("active", on);
        c.setAttribute("aria-pressed", String(on));
      });
    draw(btn.dataset.chip);
  });
  draw("all");
}

function renderGames(list) {
  $("games-grid").innerHTML = Object.values(GAMES)
    .map((g) => {
      const n = list.filter((t) => t.game === g.id).length;
      return `
        <div class="col-md-6">
          <a class="game-card" href="${routes.tournaments()}?game=${g.id}">
            <img src="${asset(g.art)}"
                 alt="${esc(g.fullName)} demo artwork"
                 loading="lazy"
                 width="800"
                 height="420">
            <span class="game-card-body">
              <i class="bi ${g.icon}" aria-hidden="true"></i>
              <strong>${esc(g.fullName)}</strong>
              <span>${esc(g.tagline)}</span>
              <em>${n} tournaments <i class="bi bi-arrow-right" aria-hidden="true"></i></em>
            </span>
          </a>
        </div>`;
    })
    .join("");
}

function renderLeaderboard() {
  const t = getFeaturedLeaderboardTournament();
  const el = $("leaderboard-preview");
  const rows = t ? getLeaderboard(t.id).slice(0, 5) : [];
  $("leaderboard-title").textContent = t ? t.name : "Standings";
  el.innerHTML = rows.length
    ? leaderboardTable(rows)
    : emptyState(
        "Standings appear once the first match is complete.",
        "bi-bar-chart-steps",
      );
  $("leaderboard-link").href = routes.leaderboard(t?.id);
}

function renderTopTeams() {
  const top = getTopTeams(4);
  $("top-teams").innerHTML = top.length
    ? top
        .map(
          ({ team, stats }) => `
            <div class="col-sm-6 col-lg-3">
              <article class="top-team">
                ${teamLogo(team, "lg")}
                <h3>
                  <a href="${routes.team(team.id)}" class="stretched-link">${esc(team.name)}</a>
                </h3>
                <p class="muted">${team.playerIds.length} members</p>
                <dl>
                  <div>
                    <dt>Wins</dt>
                    <dd>${stats.wins}</dd>
                  </div>
                  <div>
                    <dt>Points</dt>
                    <dd class="text-red">${stats.points}</dd>
                  </div>
                </dl>
              </article>
            </div>`,
        )
        .join("")
    : `<div class="col-12">${emptyState("No team stats yet.", "bi-people")}</div>`;
}

function observeReveal() {
  const els = document.querySelectorAll(".reveal");
  if (!("IntersectionObserver" in window)) {
    els.forEach((e) => e.classList.add("in"));
    return;
  }
  const io = new IntersectionObserver(
    (es) =>
      es.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      }),
    { threshold: 0.12 },
  );
  els.forEach((e) => io.observe(e));
}
