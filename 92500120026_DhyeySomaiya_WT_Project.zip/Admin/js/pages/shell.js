// pages/shell.js — player + admin dashboard pages (they share the sidebar layout).
// Phase 1 shows real runtime data in tables/stat cards. Phase 3/4 add the forms, charts and CRUD actions.
import { KEYS } from "../constants.js";
import { routes, url } from "../paths.js";
import { esc, formatCurrency, formatDate, formatDateTime } from "../utils.js";
import {
  animateCounters,
  emptyState,
  gameBadge,
  statusBadge,
  toast,
  playerAvatar,
  teamLogo,
} from "../ui.js";
import { dataTable, panel, statCard } from "../admin.js";
import { loadData, saveData, updateData } from "../storage.js";
import { resetDemoData } from "../data.js";
import { getSession } from "../auth.js";
import { getTournaments, getTournamentById } from "../tournaments.js";
import { getMatches } from "../matches.js";
import {
  getTeams,
  getTeamById,
  getTeamPlayers,
  getTeamStats,
} from "../teams.js";
import { getPlayers, getPlayerById } from "../players.js";
import { getRegistrations } from "../registration.js";
import { getLeaderboard, leaderboardTable } from "../leaderboard.js";

const tName = (id) => esc(getTournamentById(id)?.name ?? "—");

const regStatus = (s) => {
  const cls =
    s === "approved" ? "open" : s === "rejected" ? "cancelled" : "closed";
  const label = esc(s[0].toUpperCase() + s.slice(1));
  return `<span class="badge-status is-${cls}">${label}</span>`;
};

const userStatus = (s) => {
  const isActive = s === "active" || s === "approved" || s === "published";
  const cls = isActive ? "open" : "closed";
  return `<span class="badge-status is-${cls}">${esc(s)}</span>`;
};

const page = (main, html) => {
  main.innerHTML = `<div class="shell-body">${html}</div>`;
  animateCounters(main);
};

/* ───────────── ADMIN ───────────── */
const adminPages = {
  "admin-dashboard"(main) {
    const ts = getTournaments(),
      regs = getRegistrations();
    const cards = [
      {
        label: "Total Players",
        value: getPlayers().length,
        icon: "bi-person-badge",
      },
      { label: "Total Teams", value: getTeams().length, icon: "bi-people" },
      {
        label: "Active Tournaments",
        value: ts.filter((t) =>
          ["registration_open", "registration_closed", "live"].includes(
            t.status,
          ),
        ).length,
        icon: "bi-trophy",
      },
      {
        label: "Completed Tournaments",
        value: ts.filter((t) => t.status === "completed").length,
        icon: "bi-flag",
      },
      {
        label: "Pending Registrations",
        value: regs.filter((r) => r.status === "pending").length,
        icon: "bi-clipboard-check",
        href: url("registrations.html"),
      },
      {
        label: "Live Matches",
        value: getMatches().filter((m) => m.status === "live").length,
        icon: "bi-broadcast",
      },
    ];
    const quick = [
      ["Create tournament", "tournaments"],
      ["Add match", "matches"],
      ["Manage registrations", "registrations"],
      ["Update scores", "scores"],
    ];
    const quickActions = quick
      .map(
        ([l, p]) =>
          `<a class="btn btn-eh-outline" href="${url(`${p}.html`)}">${l}</a>`,
      )
      .join("\n        ");

    page(
      main,
      `
      <div class="row g-3 mb-4">
        ${cards.map(statCard).join("")}
      </div>
      <div class="quick-actions mb-4">
        ${quickActions}
      </div>
      ${panel(
        "Recent registrations",
        dataTable(
          [
            { label: "Team", cell: (r) => esc(r.teamName) },
            { label: "Tournament", cell: (r) => tName(r.tournamentId) },
            { label: "Date", cell: (r) => formatDate(r.registeredAt) },
            { label: "Status", cell: (r) => regStatus(r.status) },
          ],
          [...regs]
            .sort((a, b) => b.registeredAt.localeCompare(a.registeredAt))
            .slice(0, 6),
        ),
      )}`,
    );
  },
  "admin-tournaments": (main) =>
    page(
      main,
      panel(
        "All tournaments",
        dataTable(
          [
            {
              label: "Tournament",
              cell: (t) =>
                `<a href="${routes.tournament(t.id)}">${esc(t.name)}</a>`,
            },
            { label: "Game", cell: (t) => gameBadge(t.game) },
            { label: "Status", cell: (t) => statusBadge(t.status) },
            { label: "Prize", cell: (t) => formatCurrency(t.prizePool) },
            {
              label: "Teams",
              cell: (t) => `${t.registeredTeams.length} / ${t.maxTeams}`,
            },
            { label: "Matches", cell: (t) => t.numberOfMatches },
            { label: "Starts", cell: (t) => formatDate(t.startDate) },
          ],
          getTournaments(),
        ),
      ),
    ),
  "admin-registrations": (main) =>
    page(
      main,
      panel(
        "Registrations",
        dataTable(
          [
            { label: "Team", cell: (r) => esc(r.teamName) },
            { label: "Captain", cell: (r) => esc(r.captainName) },
            { label: "Tournament", cell: (r) => tName(r.tournamentId) },
            { label: "Registered", cell: (r) => formatDate(r.registeredAt) },
            { label: "Status", cell: (r) => regStatus(r.status) },
          ],
          [...getRegistrations()].reverse(),
          "No registrations available.",
        ),
      ),
    ),
  "admin-matches": (main) =>
    page(
      main,
      panel(
        "Matches",
        dataTable(
          [
            { label: "Tournament", cell: (m) => tName(m.tournamentId) },
            {
              label: "Match",
              cell: (m) =>
                `<a href="${routes.match(m.id)}">Match ${m.matchNumber}</a>`,
            },
            { label: "Round", cell: (m) => esc(m.round) },
            { label: "Map", cell: (m) => esc(m.map) },
            { label: "When", cell: (m) => formatDateTime(m.scheduledAt) },
            { label: "Status", cell: (m) => statusBadge(m.status) },
          ],
          getMatches(),
        ),
      ),
    ),
  "admin-scores": (main) =>
    page(
      main,
      panel(
        "Score entry — matches with results",
        dataTable(
          [
            { label: "Tournament", cell: (m) => tName(m.tournamentId) },
            { label: "Match", cell: (m) => `Match ${m.matchNumber}` },
            { label: "Teams scored", cell: (m) => m.results.length },
            { label: "Status", cell: (m) => statusBadge(m.status) },
          ],
          getMatches().filter((m) => m.results.length),
          "No scores entered yet.",
        ),
      ),
    ),
  "admin-results"(main) {
    const rows = getTournaments()
      .filter((t) => t.status === "completed")
      .map((t) => ({ t, top: getLeaderboard(t.id)[0] }));
    page(
      main,
      panel(
        "Tournament results",
        dataTable(
          [
            { label: "Tournament", cell: (r) => esc(r.t.name) },
            { label: "Winner", cell: (r) => esc(r.top?.team?.name ?? "—") },
            { label: "Points", cell: (r) => r.top?.total ?? "—" },
            { label: "Completed", cell: (r) => formatDate(r.t.endDate) },
          ],
          rows,
          "No completed tournaments yet.",
        ),
      ),
    );
  },
  "admin-teams": (main) =>
    page(
      main,
      panel(
        "Teams",
        dataTable(
          [
            {
              label: "Team",
              cell: (t) =>
                `<a class="team-cell" href="${routes.team(t.id)}">${teamLogo(t, "sm")}<span>${esc(t.name)}</span></a>`,
            },
            {
              label: "Captain",
              cell: (t) => esc(getPlayerById(t.captainId)?.username),
            },
            { label: "Game", cell: (t) => gameBadge(t.game) },
            { label: "Members", cell: (t) => t.playerIds.length },
            { label: "Wins", cell: (t) => getTeamStats(t.id).wins },
            { label: "Points", cell: (t) => getTeamStats(t.id).points },
            { label: "Status", cell: (t) => userStatus(t.status) },
          ],
          getTeams(),
        ),
      ),
    ),
  "admin-players": (main) =>
    page(
      main,
      panel(
        "Players",
        dataTable(
          [
            {
              label: "Player",
              cell: (p) =>
                `<a href="${routes.player(p.id)}">${esc(p.username)}</a>`,
            },
            { label: "Game ID", cell: (p) => esc(p.gameId) },
            { label: "Team", cell: (p) => esc(getTeamById(p.teamId)?.name) },
            { label: "Role", cell: (p) => esc(p.role) },
            { label: "Status", cell: (p) => userStatus(p.status) },
          ],
          getPlayers(),
        ),
      ),
    ),
  "admin-leaderboard"(main) {
    const list = getTournaments().filter((t) =>
      ["live", "completed"].includes(t.status),
    );
    const tournamentOptions = list
      .map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`)
      .join("");

    page(
      main,
      panel(
        "Calculated rankings",
        `
        <p class="muted">
          Ranks come from completed match results and the scoring rules — they cannot be edited by hand.
        </p>
        <label class="visually-hidden" for="al-t">Tournament</label>
        <select id="al-t" class="form-select mb-3" style="max-width:360px">
          ${tournamentOptions}
        </select>
        <div id="al-out"></div>`,
      ),
    );
    const draw = () => {
      const rows = getLeaderboard(document.getElementById("al-t")?.value);
      document.getElementById("al-out").innerHTML = rows.length
        ? leaderboardTable(rows, { full: true })
        : emptyState("No completed matches yet.", "bi-bar-chart-steps");
    };
    document.getElementById("al-t")?.addEventListener("change", draw);
    draw();
  },
  "admin-users": (main) =>
    page(
      main,
      panel(
        "Users",
        dataTable(
          [
            { label: "Name", cell: (u) => esc(u.name) },
            { label: "Email", cell: (u) => esc(u.email) },
            { label: "Role", cell: (u) => esc(u.role) },
            { label: "Status", cell: (u) => userStatus(u.status) },
            { label: "Joined", cell: (u) => formatDate(u.createdAt) },
          ],
          loadData(KEYS.users, []),
        ),
      ),
    ),
  "admin-analytics"(main) {
    const ts = getTournaments(),
      ms = getMatches(),
      regs = getRegistrations();
    const cards = [
      ["Total registrations", regs.length, "bi-clipboard-data"],
      [
        "Active tournaments",
        ts.filter((t) => ["registration_open", "live"].includes(t.status))
          .length,
        "bi-trophy",
      ],
      [
        "Completed tournaments",
        ts.filter((t) => t.status === "completed").length,
        "bi-flag",
      ],
      [
        "Matches completed",
        ms.filter((m) => m.status === "completed").length,
        "bi-check2-circle",
      ],
    ];
    page(
      main,
      `<div class="row g-3">${cards.map(([label, value, icon]) => statCard({ label, value, icon })).join("")}</div>`,
    );
  },
  "admin-announcements": (main) =>
    page(
      main,
      panel(
        "Announcements",
        dataTable(
          [
            { label: "Title", cell: (a) => esc(a.title) },
            { label: "Category", cell: (a) => esc(a.category) },
            { label: "Date", cell: (a) => formatDate(a.date) },
            { label: "Status", cell: (a) => userStatus(a.status) },
          ],
          loadData(KEYS.announcements, []),
        ),
      ),
    ),
  "admin-settings"(main) {
    const rules = loadData(KEYS.scoringRules, {});
    const rulesNote = rules.isPlaceholder
      ? "These are placeholder values until the official scoring system is set."
      : "Current scoring configuration.";

    page(
      main,
      `
      ${panel(
        "Scoring rules",
        `
        <p class="muted">
          ${rulesNote} All points are calculated from this record by scoring.js.
        </p>
        <pre class="code-block">${esc(JSON.stringify(rules, null, 2))}</pre>`,
      )}
      ${panel(
        "Demo data",
        `
        <p class="muted">
          Wipes everything stored in this browser (including your login) and re-seeds the demo data.
        </p>
        <button class="btn btn-eh" id="reset-demo">Reset demo data</button>`,
      )}`,
    );
    document.getElementById("reset-demo").addEventListener("click", () => {
      if (confirm("Reset all demo data? This also logs you out.")) {
        resetDemoData();
        location.href = routes.login();
      }
    });
  },
};

/* ───────────── PLAYER ───────────── */
function me() {
  const s = getSession();
  const player = s?.playerId ? getPlayerById(s.playerId) : null;
  const team = player ? getTeamById(player.teamId) : null;
  const regs = getRegistrations().filter(
    (r) => (team && r.teamId === team.id) || r.userId === s?.userId,
  );
  return { s, player, team, regs };
}
const noTeam = emptyState(
  "Your account isn't linked to a team yet. Register a team for a tournament to get started.",
  "bi-people",
  `<a class="btn btn-eh btn-sm" href="${routes.registration()}">Register a team</a>`,
);

const playerPages = {
  "player-dashboard"(main) {
    const { team, regs } = me();
    if (!team && !regs.length) return page(main, noTeam);
    const stats = team
      ? getTeamStats(team.id)
      : { wins: 0, kills: 0, points: 0 };
    const ids = new Set(
      regs.filter((r) => r.status === "approved").map((r) => r.tournamentId),
    );
    const upcoming = getMatches()
      .filter(
        (m) =>
          ids.has(m.tournamentId) && ["upcoming", "live"].includes(m.status),
      )
      .sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt))
      .slice(0, 5);
    let rank = "—";
    for (const id of ids) {
      const row = getLeaderboard(id).find((r) => r.teamId === team?.id);
      if (row) {
        rank = `#${row.rank}`;
        break;
      }
    }
    page(
      main,
      `
      <div class="row g-3 mb-4">
        ${statCard({ label: "Joined tournaments", value: ids.size, icon: "bi-trophy" })}
        ${statCard({ label: "Total points", value: stats.points, icon: "bi-stars" })}
        ${statCard({ label: "Wins", value: stats.wins, icon: "bi-award" })}
        ${statCard({ label: "Kills", value: stats.kills, icon: "bi-crosshair" })}
        <div class="col-6 col-xl-4">
          <div class="stat-card">
            <i class="bi bi-graph-up-arrow"></i>
            <b>${rank}</b>
            <span>Current rank</span>
          </div>
        </div>
      </div>
      ${panel(
        "Upcoming matches",
        dataTable(
          [
            { label: "Tournament", cell: (m) => tName(m.tournamentId) },
            {
              label: "Match",
              cell: (m) =>
                `<a href="${routes.match(m.id)}">Match ${m.matchNumber}</a>`,
            },
            { label: "When", cell: (m) => formatDateTime(m.scheduledAt) },
            { label: "Status", cell: (m) => statusBadge(m.status) },
          ],
          upcoming,
          "No upcoming matches.",
        ),
      )}`,
    );
  },
  "player-tournaments"(main) {
    const { regs } = me();
    page(
      main,
      panel(
        "My tournaments",
        dataTable(
          [
            {
              label: "Tournament",
              cell: (r) =>
                `<a href="${routes.tournament(r.tournamentId)}">${tName(r.tournamentId)}</a>`,
            },
            { label: "Team", cell: (r) => esc(r.teamName) },
            { label: "Registered", cell: (r) => formatDate(r.registeredAt) },
            { label: "Status", cell: (r) => regStatus(r.status) },
          ],
          regs,
          "You haven't registered for any tournament yet.",
        ),
        `<a class="btn btn-eh btn-sm" href="${routes.tournaments()}">Find tournaments</a>`,
      ),
    );
  },
  "player-matches"(main) {
    const { regs } = me();
    const ids = new Set(
      regs.filter((r) => r.status === "approved").map((r) => r.tournamentId),
    );
    page(
      main,
      panel(
        "My matches",
        dataTable(
          [
            { label: "Tournament", cell: (m) => tName(m.tournamentId) },
            {
              label: "Match",
              cell: (m) =>
                `<a href="${routes.match(m.id)}">Match ${m.matchNumber}</a>`,
            },
            { label: "When", cell: (m) => formatDateTime(m.scheduledAt) },
            { label: "Status", cell: (m) => statusBadge(m.status) },
          ],
          getMatches().filter((m) => ids.has(m.tournamentId)),
          "No matches yet — join a tournament first.",
        ),
      ),
    );
  },
  "player-team"(main) {
    const { team } = me();
    if (!team) return page(main, noTeam);

    const playersHtml = getTeamPlayers(team)
      .map(
        (p) => `
        <div class="col-sm-6 col-lg-3">
          <a class="player-card" href="${routes.player(p.id)}">
            ${playerAvatar(p, "lg")}
            <strong>${esc(p.username)}</strong>
            <span>${esc(p.role)}${p.id === team.captainId ? " · Captain" : ""}</span>
          </a>
        </div>`,
      )
      .join("");

    page(
      main,
      `
      <div class="d-flex align-items-center gap-3 mb-4">
        ${teamLogo(team, "xl")}
        <div>
          <h2 class="h3 mb-1">${esc(team.name)}</h2>
          ${gameBadge(team.game)}
        </div>
      </div>
      <div class="row g-3">
        ${playersHtml}
      </div>`,
    );
  },
  "player-achievements"(main) {
    const { player, team } = me();
    const list = [
      ...(player?.achievements ?? []),
      ...(team?.achievements ?? []),
    ];
    page(
      main,
      list.length
        ? panel(
            "Achievements",
            `<ul class="rules-list">${list.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`,
          )
        : emptyState(
            "No achievements yet. Win a match or place on a leaderboard to earn your first.",
            "bi-award",
          ),
    );
  },
  "player-notifications"(main) {
    const { regs } = me();
    const items = [
      ...regs.map((r) => {
        const t = getTournamentById(r.tournamentId);
        const tournamentName = t?.name ?? "a tournament";
        return {
          date: r.registeredAt,
          text: `${r.teamName}: registration for ${tournamentName} is ${r.status}.`,
        };
      }),
      ...loadData(KEYS.announcements, [])
        .filter((a) => a.status === "published")
        .map((a) => ({ date: a.date, text: a.title })),
    ]
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 12);

    const listHtml = items
      .map(
        (n) => `
        <li>
          <i class="bi bi-bell" aria-hidden="true"></i>
          <span>${esc(n.text)}</span>
          <time>${formatDate(n.date)}</time>
        </li>`,
      )
      .join("");

    page(
      main,
      panel("Notifications", `<ul class="notif-list">${listHtml}</ul>`),
    );
  },
  "player-settings"(main) {
    const { s } = me();
    page(
      main,
      panel(
        "Profile settings",
        `
        <form id="prof" class="mw-form" novalidate>
          <div class="mb-3">
            <label class="form-label" for="p-name">Display name</label>
            <input class="form-control" id="p-name" value="${esc(s.name)}" required minlength="2">
            <div class="invalid-feedback">Name needs at least 2 characters.</div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="p-email">Email</label>
            <input class="form-control" id="p-email" value="${esc(s.email)}" disabled>
          </div>
          <button class="btn btn-eh" type="submit">Save changes</button>
        </form>`,
      ),
    );
    const f = document.getElementById("prof");
    f.addEventListener("submit", (e) => {
      e.preventDefault();
      f.classList.add("was-validated");
      if (!f.checkValidity()) return;
      const name = document.getElementById("p-name").value.trim();
      updateData(
        KEYS.users,
        (u) => u.map((x) => (x.id === s.userId ? { ...x, name } : x)),
        [],
      );
      saveData(KEYS.session, { ...s, name });
      toast("Profile updated.");
      document.querySelector(".topbar-user span")?.replaceChildren(name);
    });
  },
};

export function render(key, { main }) {
  const fn = adminPages[key] ?? playerPages[key];
  if (!fn) throw new Error(`No renderer for page "${key}"`);
  fn(main);
}
