// pages/public.js — every public + auth page. Each page is one small function in `PAGES`.
import { GAMES, KEYS } from "../constants.js";
import { routes } from "../paths.js";
import {
  esc,
  formatCurrency,
  formatDate,
  formatDateTime,
  getParam,
  debounce,
} from "../utils.js";
import {
  asset,
  emptyState,
  gameBadge,
  pageHeader,
  playerAvatar,
  sectionHeader,
  statusBadge,
  teamLogo,
  toast,
} from "../ui.js";
import {
  filterTournaments,
  getPublicTournaments,
  getTournamentById,
  registrationState,
  tournamentCard,
} from "../tournaments.js";
import {
  getMatchById,
  getMatches,
  getMatchStandings,
  matchCard,
} from "../matches.js";
import {
  getTeamById,
  getTeamPlayers,
  getTeams,
  getTeamStats,
  teamCard,
} from "../teams.js";
import { getPlayerById } from "../players.js";
import { getLeaderboard, leaderboardTable } from "../leaderboard.js";
import { addRegistration, hasRegistered } from "../registration.js";
import { getSession, homeFor, login, registerUser, safeNext } from "../auth.js";
import { loadData } from "../storage.js";

const wrap = (inner, cls = "") => `
  <section class="section ${cls}">
    <div class="container">
      ${inner}
    </div>
  </section>`;

const field = (id, label, attrs = "", hint = "") => `
  <div class="mb-3">
    <label class="form-label" for="${id}">${label}</label>
    <input class="form-control" id="${id}" name="${id}" ${attrs}>
    <div class="invalid-feedback">${hint || "This field is required."}</div>
  </div>`;

const select = (id, label, options, selected = "") => {
  const optionsHtml = options
    .map(
      ([v, l]) =>
        `<option value="${esc(v)}" ${v === selected ? "selected" : ""}>${esc(l)}</option>`,
    )
    .join("\n        ");
  return `
    <div class="mb-3">
      <label class="form-label" for="${id}">${label}</label>
      <select class="form-select" id="${id}" name="${id}">
        ${optionsHtml}
      </select>
    </div>`;
};

const notFound = (what, back) =>
  pageHeader(`${what} not found`, "It may have been removed.") +
  wrap(
    emptyState(
      `We couldn't find that ${what.toLowerCase()}.`,
      "bi-search",
      `<a class="btn btn-eh btn-sm" href="${back}">Go back</a>`,
    ),
  );

/* ───────────── tournaments ───────────── */
function tournamentsPage(main) {
  const all = getPublicTournaments();
  const gameOptions = Object.values(GAMES)
    .map((g) => `<option value="${g.id}">${esc(g.name)}</option>`)
    .join("\n        ");

  main.innerHTML =
    pageHeader(
      "Tournaments",
      "Find your next lobby. Filter by game, status and prize.",
      [{ label: "Home", href: routes.home() }, { label: "Tournaments" }],
    ) +
    wrap(`
    <form class="filter-bar" role="search" aria-label="Filter tournaments" onsubmit="return false">
      <div class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <label class="visually-hidden" for="t-search">Search tournaments</label>
        <input id="t-search" type="search" class="form-control" placeholder="Search tournaments">
      </div>
      <label class="visually-hidden" for="t-game">Game</label>
      <select id="t-game" class="form-select">
        <option value="all">All games</option>
        ${gameOptions}
      </select>
      <label class="visually-hidden" for="t-status">Status</label>
      <select id="t-status" class="form-select">
        <option value="all">All statuses</option>
        <option value="registration_open">Registration open</option>
        <option value="upcoming">Upcoming</option>
        <option value="registration_closed">Registration closed</option>
        <option value="live">Live</option>
        <option value="completed">Completed</option>
      </select>
      <label class="visually-hidden" for="t-size">Matches</label>
      <select id="t-size" class="form-select">
        <option value="0">Any format</option>
        <option value="4">4 matches</option>
        <option value="6">6 matches</option>
        <option value="8">8 matches</option>
      </select>
      <label class="visually-hidden" for="t-sort">Sort</label>
      <select id="t-sort" class="form-select">
        <option value="date_asc">Date: soonest</option>
        <option value="date_desc">Date: latest</option>
        <option value="prize_desc">Prize: high to low</option>
        <option value="prize_asc">Prize: low to high</option>
      </select>
    </form>
    <p class="result-count" id="t-count" aria-live="polite"></p>
    <div class="row g-4" id="t-grid"></div>`);

  const $ = (id) => document.getElementById(id);
  const g = getParam("game");
  if (g && GAMES[g]) $("t-game").value = g;
  const draw = () => {
    const size = Number($("t-size").value);
    const rows = filterTournaments(all, {
      search: $("t-search").value,
      game: $("t-game").value,
      status: $("t-status").value,
      sort: $("t-sort").value,
    }).filter((t) => !size || t.numberOfMatches === size);
    $("t-count").textContent =
      `${rows.length} tournament${rows.length === 1 ? "" : "s"}`;
    $("t-grid").innerHTML = rows.length
      ? rows
          .map(
            (t) => `<div class="col-md-6 col-xl-4">${tournamentCard(t)}</div>`,
          )
          .join("")
      : `<div class="col-12">${emptyState("No tournaments found. Try a different filter.", "bi-trophy")}</div>`;
  };
  $("t-search").addEventListener("input", debounce(draw, 150));
  ["t-game", "t-status", "t-size", "t-sort"].forEach((id) =>
    $(id).addEventListener("change", draw),
  );
  draw();
}

function tournamentDetailsPage(main) {
  const t = getTournamentById(getParam("id"));
  if (!t || t.status === "draft") {
    main.innerHTML = notFound("Tournament", routes.tournaments());
    return;
  }
  const st = registrationState(t);
  const matches = getMatches()
    .filter((m) => m.tournamentId === t.id)
    .sort((a, b) => a.matchNumber - b.matchNumber);
  const teams = t.registeredTeams.map(getTeamById).filter(Boolean);
  const board = getLeaderboard(t.id);
  const cta = st.enabled
    ? `<a class="btn btn-eh btn-lg" href="${routes.registration(t.id)}">${st.label}</a>`
    : `<button class="btn btn-eh btn-lg" disabled>${st.label}</button>`;
  const stat = (l, v) => `
    <div class="detail-stat">
      <small>${l}</small>
      <b>${v}</b>
    </div>`;

  const tabs = ["overview", "rules", "schedule", "teams", "leaderboard"]
    .map(
      (k, i) => `
        <li class="nav-item" role="presentation">
          <button class="nav-link ${i ? "" : "active"}"
                  data-bs-toggle="tab"
                  data-bs-target="#tab-${k}"
                  type="button"
                  role="tab"
                  aria-selected="${!i}">
            ${k[0].toUpperCase() + k.slice(1)}
          </button>
        </li>`,
    )
    .join("");

  const prizeList = t.prizeDistribution
    .map(
      (p) => `
        <li>
          <span>${esc(p.place)}</span>
          <b>${formatCurrency(Math.round((t.prizePool * p.share) / 100))}</b>
        </li>`,
    )
    .join("");

  const rulesList = t.rules.map((r) => `<li>${esc(r)}</li>`).join("");

  const scheduleContent = matches.length
    ? matches
        .map((m) => `<div class="col-md-6 col-xl-4">${matchCard(m)}</div>`)
        .join("")
    : `<div class="col-12">${emptyState("The schedule has not been published.", "bi-calendar-x")}</div>`;

  const teamsContent = teams.length
    ? teams
        .map((tm) => `<div class="col-md-6 col-xl-4">${teamCard(tm)}</div>`)
        .join("")
    : `<div class="col-12">${emptyState("No teams have been approved yet.", "bi-people")}</div>`;

  const leaderboardContent = board.length
    ? leaderboardTable(board, { full: true })
    : emptyState(
        "Standings appear after the first completed match.",
        "bi-bar-chart-steps",
      );

  main.innerHTML = `
    <header class="detail-hero" style="--banner:url('${asset(t.banner)}')">
      <div class="container">
        <nav aria-label="Breadcrumb">
          <ol class="eh-breadcrumb">
            <li><a href="${routes.home()}">Home</a></li>
            <li><a href="${routes.tournaments()}">Tournaments</a></li>
            <li aria-current="page">${esc(t.name)}</li>
          </ol>
        </nav>
        <div class="d-flex gap-2 flex-wrap mb-3">
          ${gameBadge(t.game)}
          ${statusBadge(t.status)}
        </div>
        <h1>${esc(t.name)}</h1>
        <p class="lead-text">${esc(t.description)}</p>
        <div class="mt-4">${cta}</div>
      </div>
    </header>
    ${wrap(`
      <div class="detail-stats">
        ${stat("Prize Pool", formatCurrency(t.prizePool))}
        ${stat("Teams", `${t.registeredTeams.length} / ${t.maxTeams}`)}
        ${stat("Matches", t.numberOfMatches)}
        ${stat("Team Size", `${t.teamSize} players`)}
        ${stat("Starts", formatDate(t.startDate))}
        ${stat("Registration Deadline", formatDate(t.registrationDeadline))}
      </div>
      <ul class="nav eh-tabs" role="tablist">
        ${tabs}
      </ul>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-overview" role="tabpanel">
          <div class="row g-4">
            <div class="col-lg-7">
              <h2 class="h4">Format</h2>
              <p>${esc(t.format)}</p>
              <h2 class="h4 mt-4">How points work</h2>
              <p>
                Each match score is placement points + kill points + bonus.
                Your tournament total is the sum of all ${t.numberOfMatches} match scores.
              </p>
            </div>
            <div class="col-lg-5">
              <h2 class="h4">Prize distribution</h2>
              <ul class="prize-list">
                ${prizeList}
              </ul>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="tab-rules" role="tabpanel">
          <ol class="rules-list">
            ${rulesList}
          </ol>
        </div>
        <div class="tab-pane fade" id="tab-schedule" role="tabpanel">
          <div class="row g-3">
            ${scheduleContent}
          </div>
        </div>
        <div class="tab-pane fade" id="tab-teams" role="tabpanel">
          <div class="row g-3">
            ${teamsContent}
          </div>
        </div>
        <div class="tab-pane fade" id="tab-leaderboard" role="tabpanel">
          ${leaderboardContent}
        </div>
      </div>`)}`;
}

/* ───────────── matches ───────────── */
function matchesPage(main) {
  const tournaments = getPublicTournaments();
  const gameOptions = Object.values(GAMES)
    .map((g) => `<option value="${g.id}">${esc(g.name)}</option>`)
    .join("\n        ");
  const tournamentOptions = tournaments
    .map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`)
    .join("\n        ");

  main.innerHTML =
    pageHeader("Matches", "Live lobbies, what's next and what just finished.", [
      { label: "Home", href: routes.home() },
      { label: "Matches" },
    ]) +
    wrap(`
    <form class="filter-bar" onsubmit="return false">
      <label class="visually-hidden" for="m-game">Game</label>
      <select id="m-game" class="form-select">
        <option value="all">All games</option>
        ${gameOptions}
      </select>
      <label class="visually-hidden" for="m-t">Tournament</label>
      <select id="m-t" class="form-select">
        <option value="all">All tournaments</option>
        ${tournamentOptions}
      </select>
      <label class="visually-hidden" for="m-s">Status</label>
      <select id="m-s" class="form-select">
        <option value="all">All statuses</option>
        <option value="live">Live</option>
        <option value="upcoming">Upcoming</option>
        <option value="completed">Completed</option>
      </select>
    </form>
    <div id="m-groups"></div>`);

  const $ = (id) => document.getElementById(id);
  const draw = () => {
    const g = $("m-game").value,
      t = $("m-t").value,
      s = $("m-s").value;
    const rows = getMatches().filter((m) => {
      const tr = tournaments.find((x) => x.id === m.tournamentId);
      return (
        tr &&
        (g === "all" || tr.game === g) &&
        (t === "all" || m.tournamentId === t) &&
        (s === "all" || m.status === s) &&
        m.status !== "cancelled"
      );
    });
    const groups = [
      ["live", "Live matches", "No live matches currently."],
      ["upcoming", "Upcoming matches", "No upcoming matches."],
      ["completed", "Completed matches", "No completed matches."],
    ].filter(([k]) => s === "all" || s === k);
    $("m-groups").innerHTML = groups
      .map(([k, title, empty]) => {
        const list = rows
          .filter((m) => m.status === k)
          .sort((a, b) =>
            k === "completed"
              ? b.scheduledAt.localeCompare(a.scheduledAt)
              : a.scheduledAt.localeCompare(b.scheduledAt),
          );
        const matchCards = list.length
          ? list
              .map(
                (m) => `<div class="col-md-6 col-xl-4">${matchCard(m)}</div>`,
              )
              .join("")
          : `<div class="col-12">${emptyState(empty, "bi-controller")}</div>`;
        return `
          <div class="mb-5">
            ${sectionHeader(title)}
            <div class="row g-3">
              ${matchCards}
            </div>
          </div>`;
      })
      .join("");
  };
  ["m-game", "m-t", "m-s"].forEach((id) =>
    $(id).addEventListener("change", draw),
  );
  draw();
}

function matchDetailsPage(main) {
  const m = getMatchById(getParam("id"));
  if (!m) {
    main.innerHTML = notFound("Match", routes.matches());
    return;
  }
  const t = getTournamentById(m.tournamentId);
  const rows = getMatchStandings(m);
  const rowsHtml = rows
    .map(
      (r, i) => `
      <tr class="${i < 3 && m.status === "completed" ? `rank-top rank-${i + 1}` : ""}">
        <td><span class="rank-pill">${i + 1}</span></td>
        <td>
          <a class="team-cell" href="${routes.team(r.teamId)}">
            ${teamLogo(r.team, "sm")}
            <span>${esc(r.team?.name)}</span>
          </a>
        </td>
        <td>${r.placement ?? "—"}</td>
        <td>${r.kills}</td>
        <td>${r.points.placementPoints}</td>
        <td>${r.points.killPoints}</td>
        <td>${r.points.bonus}</td>
        <td class="fw-bold text-red">${r.points.total}</td>
      </tr>`,
    )
    .join("");

  const tableOrEmpty = rows.length
    ? `<div class="table-responsive eh-table-wrap">
        <table class="eh-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Team</th>
              <th>Placement</th>
              <th>Kills</th>
              <th>Placement Pts</th>
              <th>Kill Pts</th>
              <th>Bonus</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>`
    : emptyState(
        `Match ${m.matchNumber} starts ${formatDateTime(m.scheduledAt)}. ${m.teamIds.length} teams are scheduled.`,
        "bi-calendar-event",
      );

  main.innerHTML =
    pageHeader(
      `${t?.name ?? "Tournament"} — Match ${m.matchNumber}`,
      `${m.round} · ${m.map} · ${formatDateTime(m.scheduledAt)}`,
      [
        { label: "Home", href: routes.home() },
        { label: "Matches", href: routes.matches() },
        { label: `Match ${m.matchNumber}` },
      ],
    ) +
    wrap(`
    <div class="d-flex gap-2 flex-wrap mb-4">
      ${t ? gameBadge(t.game) : ""}
      ${statusBadge(m.status)}
      ${t ? `<a class="btn btn-eh-outline btn-sm" href="${routes.tournament(t.id)}">View tournament</a>` : ""}
    </div>
    ${tableOrEmpty}`);
}

/* ───────────── leaderboard, teams, players ───────────── */
function leaderboardPage(main) {
  const list = getPublicTournaments().filter((t) =>
    ["live", "completed"].includes(t.status),
  );
  const optionsHtml = list
    .map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`)
    .join("");

  main.innerHTML =
    pageHeader(
      "Leaderboard",
      "Standings are calculated from completed match results.",
      [{ label: "Home", href: routes.home() }, { label: "Leaderboard" }],
    ) +
    wrap(`
    <form class="filter-bar" onsubmit="return false">
      <label class="visually-hidden" for="l-t">Tournament</label>
      <select id="l-t" class="form-select">
        ${optionsHtml}
      </select>
      <div class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <label class="visually-hidden" for="l-q">Search team</label>
        <input id="l-q" type="search" class="form-control" placeholder="Search team">
      </div>
    </form>
    <div id="l-podium" class="row g-3 mb-4"></div>
    <div id="l-table"></div>`);

  if (!list.length) {
    document.getElementById("l-table").innerHTML = emptyState(
      "No tournament has results yet.",
      "bi-bar-chart-steps",
    );
    return;
  }
  const $ = (id) => document.getElementById(id);
  const wanted = getParam("tournament");
  if (wanted && list.some((t) => t.id === wanted)) $("l-t").value = wanted;
  const draw = () => {
    const all = getLeaderboard($("l-t").value),
      q = $("l-q").value.trim().toLowerCase();
    $("l-podium").innerHTML = all
      .slice(0, 3)
      .map(
        (r) => `
          <div class="col-md-4">
            <div class="podium rank-${r.rank}">
              <span class="podium-rank">${r.rank}</span>
              ${teamLogo(r.team, "lg")}
              <h3>${esc(r.team?.name)}</h3>
              <b>${r.total} pts</b>
              <small>${r.wins} wins · ${r.kills} kills</small>
            </div>
          </div>`,
      )
      .join("");
    const rows = all.filter(
      (r) => !q || r.team?.name.toLowerCase().includes(q),
    );
    $("l-table").innerHTML = rows.length
      ? leaderboardTable(rows, { full: true })
      : emptyState("No teams match your search.", "bi-search");
  };
  $("l-t").addEventListener("change", draw);
  $("l-q").addEventListener("input", debounce(draw, 150));
  draw();
}

function teamsPage(main) {
  const gameOptions = Object.values(GAMES)
    .map((g) => `<option value="${g.id}">${esc(g.name)}</option>`)
    .join("");

  main.innerHTML =
    pageHeader("Teams", "Every squad competing on Esport Hub.", [
      { label: "Home", href: routes.home() },
      { label: "Teams" },
    ]) +
    wrap(`
    <form class="filter-bar" onsubmit="return false">
      <div class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <label class="visually-hidden" for="tm-q">Search teams</label>
        <input id="tm-q" type="search" class="form-control" placeholder="Search teams">
      </div>
      <label class="visually-hidden" for="tm-g">Game</label>
      <select id="tm-g" class="form-select">
        <option value="all">All games</option>
        ${gameOptions}
      </select>
    </form>
    <div class="row g-3" id="tm-grid"></div>`);

  const $ = (id) => document.getElementById(id);
  const teams = getTeams().filter((t) => t.status === "approved");
  const draw = () => {
    const q = $("tm-q").value.trim().toLowerCase(),
      g = $("tm-g").value;
    const rows = teams.filter(
      (t) =>
        (g === "all" || t.game === g) &&
        (!q ||
          t.name.toLowerCase().includes(q) ||
          t.tag.toLowerCase().includes(q)),
    );
    $("tm-grid").innerHTML = rows.length
      ? rows
          .map((t) => `<div class="col-md-6 col-xl-4">${teamCard(t)}</div>`)
          .join("")
      : `<div class="col-12">${emptyState("No teams found.", "bi-people")}</div>`;
  };
  $("tm-q").addEventListener("input", debounce(draw, 150));
  $("tm-g").addEventListener("change", draw);
  draw();
}

function teamDetailsPage(main) {
  const team = getTeamById(getParam("id"));
  if (!team) {
    main.innerHTML = notFound("Team", routes.teams());
    return;
  }
  const s = getTeamStats(team.id),
    roster = getTeamPlayers(team);

  const statsHtml = [
    ["Tournaments", s.tournaments],
    ["Matches", s.matches],
    ["Wins", s.wins],
    ["Kills", s.kills],
    ["Points", s.points],
  ]
    .map(
      ([l, v]) => `
      <div class="detail-stat">
        <small>${l}</small>
        <b>${v}</b>
      </div>`,
    )
    .join("");

  const rosterHtml = roster
    .map(
      (p) => `
      <div class="col-sm-6 col-lg-3">
        <a class="player-card" href="${routes.player(p.id)}">
          ${playerAvatar(p, "lg")}
          <strong>${esc(p.username)}</strong>
          <span>${esc(p.role)}${p.id === team.captainId ? " · Captain" : ""}</span>
        </a>
      </div>`,
    )
    .join("");

  const achievementsHtml = team.achievements.length
    ? `<ul class="rules-list">${team.achievements.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`
    : emptyState("No achievements yet.", "bi-award");

  main.innerHTML =
    pageHeader(team.name, team.about, [
      { label: "Home", href: routes.home() },
      { label: "Teams", href: routes.teams() },
      { label: team.name },
    ]) +
    wrap(`
    <div class="d-flex align-items-center gap-3 mb-4">
      ${teamLogo(team, "xl")}
      ${gameBadge(team.game)}
    </div>
    <div class="detail-stats">
      ${statsHtml}
    </div>
    <h2 class="h4 mb-3">Roster</h2>
    <div class="row g-3 mb-5">
      ${rosterHtml}
    </div>
    <h2 class="h4 mb-3">Achievements</h2>
    ${achievementsHtml}`);
}

function playerProfilePage(main) {
  const p = getPlayerById(getParam("id"));
  if (!p) {
    main.innerHTML = notFound("Player", routes.teams());
    return;
  }
  const team = getTeamById(p.teamId),
    s = team
      ? getTeamStats(team.id)
      : { matches: 0, wins: 0, kills: 0, points: 0 };

  const statsHtml = [
    ["Team matches", s.matches],
    ["Team wins", s.wins],
    ["Team kills", s.kills],
    ["Team points", s.points],
  ]
    .map(
      ([l, v]) => `
      <div class="detail-stat">
        <small>${l}</small>
        <b>${v}</b>
      </div>`,
    )
    .join("");

  const achievementsHtml = p.achievements.length
    ? `<ul class="rules-list">${p.achievements.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`
    : emptyState("No achievements yet.", "bi-award");

  main.innerHTML =
    pageHeader(p.username, `${p.role} · Game ID ${p.gameId}`, [
      { label: "Home", href: routes.home() },
      { label: "Teams", href: routes.teams() },
      ...(team ? [{ label: team.name, href: routes.team(team.id) }] : []),
      { label: p.username },
    ]) +
    wrap(`
    <div class="d-flex align-items-center gap-3 mb-4">
      ${playerAvatar(p, "xl")}
      <div>
        ${gameBadge(p.game)}
        <p class="muted mt-2 mb-0">
          ${team ? `Plays for <a href="${routes.team(team.id)}">${esc(team.name)}</a>` : "Free agent"}
        </p>
      </div>
    </div>
    <div class="detail-stats">
      ${statsHtml}
    </div>
    <h2 class="h4 mb-3">Achievements</h2>
    ${achievementsHtml}`);
}

/* ───────────── news / about / contact ───────────── */
function newsPage(main) {
  const items = loadData(KEYS.announcements, [])
    .filter((a) => a.status === "published")
    .sort((a, b) => b.date.localeCompare(a.date));

  const itemsHtml = items.length
    ? `<div class="row g-4">
        ${items
          .map(
            (a, i) => `
            <div class="col-md-6 col-xl-4">
              <article class="news-card">
                <div class="news-art hue-${i % 4}" aria-hidden="true">
                  <i class="bi bi-megaphone-fill"></i>
                </div>
                <div class="news-body">
                  <span class="news-cat">${esc(a.category)}</span>
                  <h2>${esc(a.title)}</h2>
                  <time datetime="${esc(a.date)}">${formatDate(a.date)}</time>
                  <p>${esc(a.content.slice(0, 120))}…</p>
                  <button class="btn btn-eh-outline btn-sm" data-read="${esc(a.id)}">Read More</button>
                </div>
              </article>
            </div>`,
          )
          .join("")}
      </div>`
    : emptyState("No announcements yet.", "bi-megaphone");

  main.innerHTML =
    pageHeader(
      "News & Announcements",
      "Results, rule changes and event updates.",
      [{ label: "Home", href: routes.home() }, { label: "News" }],
    ) +
    wrap(itemsHtml) +
    `
    <div class="modal fade" id="newsModal" tabindex="-1" aria-hidden="true" aria-labelledby="newsTitle">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content eh-modal">
          <div class="modal-header">
            <h2 class="modal-title h4" id="newsTitle"></h2>
            <button class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="newsBody"></div>
        </div>
      </div>
    </div>`;

  main.addEventListener("click", (e) => {
    const b = e.target.closest("[data-read]");
    if (!b) return;
    const a = items.find((x) => x.id === b.dataset.read);
    document.getElementById("newsTitle").textContent = a.title;
    document.getElementById("newsBody").innerHTML = `
      <p class="muted">${esc(a.category)} · ${formatDate(a.date)} · ${esc(a.author)}</p>
      <p>${esc(a.content)}</p>`;
    window.bootstrap.Modal.getOrCreateInstance(
      document.getElementById("newsModal"),
    ).show();
  });
}

function aboutPage(main) {
  main.innerHTML =
    pageHeader(
      "About Esport Hub",
      "A tournament platform built around fair, points-based competition.",
      [{ label: "Home", href: routes.home() }, { label: "About" }],
    ) +
    wrap(`
    <div class="row g-4">
      <div class="col-lg-7">
        <p>
          Esport Hub runs BGMI and Free Fire tournaments end to end: registration, lobby schedules,
          score entry and live standings. Every match score is placement points plus kill points plus bonus,
          and your tournament total is the sum of all matches.
        </p>
        <p>
          This is a college demo project. Data is stored in your browser, so nothing here is sent to a server.
        </p>
      </div>
      <div class="col-lg-5">
        <div class="panel">
          <h2 class="h5" id="terms">Terms</h2>
          <p class="muted">Demo only. Use of this prototype is for learning and evaluation.</p>
          <h2 class="h5" id="privacy">Privacy</h2>
          <p class="muted">
            Accounts and registrations live in your browser's localStorage and never leave your device.
          </p>
        </div>
      </div>
    </div>`);
}

function contactPage(main) {
  main.innerHTML =
    pageHeader(
      "Contact",
      "Questions about a tournament or a ruling? Send us a message.",
      [{ label: "Home", href: routes.home() }, { label: "Contact" }],
    ) +
    wrap(`
    <div class="row justify-content-center">
      <div class="col-lg-7">
        <form id="contact-form" class="panel" novalidate>
          ${field("c-name", "Your name", 'required autocomplete="name"')}
          ${field("c-email", "Email", 'type="email" required autocomplete="email"', "Enter a valid email address.")}
          <div class="mb-3">
            <label class="form-label" for="c-msg">Message</label>
            <textarea class="form-control" id="c-msg" rows="5" required minlength="10"></textarea>
            <div class="invalid-feedback">Please write at least 10 characters.</div>
          </div>
          <button class="btn btn-eh" type="submit">Send message</button>
        </form>
      </div>
    </div>`);

  const f = document.getElementById("contact-form");
  f.addEventListener("submit", (e) => {
    e.preventDefault();
    f.classList.add("was-validated");
    if (!f.checkValidity()) return;
    toast(
      "Message sent. Our support desk replies within a day (demo — nothing is actually sent).",
    );
    f.reset();
    f.classList.remove("was-validated");
  });
}

/* ───────────── registration ───────────── */
function registrationPage(main) {
  const open = getPublicTournaments().filter(
    (t) => t.status === "registration_open",
  );

  const formHtml = open.length
    ? `
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <form id="reg-form" class="panel" novalidate>
            ${select(
              "r-t",
              "Tournament",
              open.map((t) => [t.id, `${t.name} — ${GAMES[t.game].name}`]),
              getParam("tournament") ?? open[0].id,
            )}
            <div class="row">
              <div class="col-md-6">
                ${field("r-team", "Team name", 'required minlength="3"', "Team name needs at least 3 characters.")}
              </div>
              <div class="col-md-6">
                ${field("r-captain", "Captain name", "required")}
              </div>
              <div class="col-md-6">
                ${field("r-email", "Email", 'type="email" required', "Enter a valid email address.")}
              </div>
              <div class="col-md-6">
                ${field(
                  "r-phone",
                  "Phone",
                  'inputmode="numeric" required pattern="[0-9]{10}"',
                  "Enter a 10-digit phone number.",
                )}
              </div>
            </div>
            ${field(
              "r-gid",
              "Captain Game ID",
              'inputmode="numeric" required pattern="[0-9]{6,12}"',
              "Game ID is 6–12 digits.",
            )}
            <div class="row">
              <div class="col-md-4">
                ${field("r-m1", "Member 2", "required")}
              </div>
              <div class="col-md-4">
                ${field("r-m2", "Member 3", "required")}
              </div>
              <div class="col-md-4">
                ${field("r-m3", "Member 4", "required")}
              </div>
            </div>
            <button class="btn btn-eh btn-lg" type="submit">Submit registration</button>
          </form>
        </div>
      </div>
      <div class="modal fade" id="regModal" tabindex="-1" aria-labelledby="regTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content eh-modal text-center p-3">
            <div class="modal-body">
              <i class="bi bi-check-circle-fill success-icon" aria-hidden="true"></i>
              <h2 class="h4" id="regTitle">Registration submitted</h2>
              <p class="muted" id="regMsg"></p>
              <a id="regLink" class="btn btn-eh" href="#">View my tournaments</a>
            </div>
          </div>
        </div>
      </div>`
    : emptyState(
        "No tournaments are accepting registrations right now.",
        "bi-clipboard-x",
        `<a class="btn btn-eh btn-sm" href="${routes.tournaments()}">Browse tournaments</a>`,
      );

  main.innerHTML =
    pageHeader(
      "Register your team",
      "Fill in your squad details. An admin approves entries.",
      [
        { label: "Home", href: routes.home() },
        { label: "Tournaments", href: routes.tournaments() },
        { label: "Registration" },
      ],
    ) + wrap(formHtml);

  const f = document.getElementById("reg-form");
  if (!f) return;
  f.addEventListener("submit", (e) => {
    e.preventDefault();
    f.classList.add("was-validated");
    if (!f.checkValidity()) {
      toast("Please fix the highlighted fields.", "danger");
      return;
    }
    const v = (id) => document.getElementById(id).value.trim();
    const t = getTournamentById(v("r-t"));
    if (hasRegistered(t.id, v("r-team"))) {
      toast(
        `"${v("r-team")}" is already registered for this tournament.`,
        "danger",
      );
      return;
    }
    if (t.registeredTeams.length >= t.maxTeams) {
      toast("This tournament is full.", "danger");
      return;
    }
    const reg = addRegistration({
      tournamentId: t.id,
      teamId: null,
      teamName: v("r-team"),
      captainName: v("r-captain"),
      email: v("r-email"),
      phone: v("r-phone"),
      gameId: v("r-gid"),
      members: [v("r-captain"), v("r-m1"), v("r-m2"), v("r-m3")],
      userId: getSession()?.userId ?? null,
    });
    document.getElementById("regMsg").textContent =
      `${reg.teamName} is pending approval for ${t.name}.`;
    document.getElementById("regLink").href = getSession()
      ? new URL("../player/tournaments.html", import.meta.url).href
      : routes.login("player/tournaments.html");
    window.bootstrap.Modal.getOrCreateInstance(
      document.getElementById("regModal"),
    ).show();
    f.reset();
    f.classList.remove("was-validated");
  });
}

/* ───────────── auth & js validations ───────────── */
// JS Validation Rules (for Web Technology Lab Project):
// Fig 1.1: All fields are required
// Fig 1.2: Password Length (min 8 chars)
// Fig 1.3: Email Pattern (valid user@domain.com regex)
// Fig 1.4: Password Pattern (uppercase, lowercase, number, special char)
// Fig 1.5: Phone number pattern (exactly 10 digits)

const JS_VALIDATORS = {
  emailRegex: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  passwordPattern:
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/,
  phoneRegex: /^[0-9]{10}$/,

  validateField(type, value) {
    const v = String(value || "").trim();

    // All fields are required check
    if (!v) {
      if (type === "name")
        return { ok: false, error: "Full Name is required." };
      if (type === "email")
        return {
          ok: false,
          error: "Email address is required.",
        };
      if (type === "phone")
        return {
          ok: false,
          error: "Phone number is required.",
        };
      if (type === "password")
        return { ok: false, error: "Password is required." };
      return { ok: false, error: "This field is required." };
    }

    // Email Pattern check
    if (type === "email") {
      if (!this.emailRegex.test(v)) {
        return {
          ok: false,
          error:
            "Invalid email pattern! Format must be: username@domain.com (e.g. player@esporthub.demo).",
        };
      }
    }

    // Phone number pattern check
    if (type === "phone") {
      if (!this.phoneRegex.test(v)) {
        return {
          ok: false,
          error:
            "Invalid phone pattern! Must be exactly 10 digits (e.g. 9876543210).",
        };
      }
    }

    // Password checks
    if (type === "password") {
      // Password Length check (min 8 chars)
      if (value.length < 8) {
        return {
          ok: false,
          error: `Password length must be at least 8 characters (current: ${value.length}).`,
        };
      }
      // Password Pattern check
      if (!this.passwordPattern.test(value)) {
        return {
          ok: false,
          error:
            "Password pattern error! Must include at least 1 uppercase (A-Z), 1 lowercase (a-z), 1 number (0-9), and 1 special symbol (!@#$%^&*).",
        };
      }
    }

    return { ok: true, error: null };
  },
};

function setFieldError(inputEl, errEl, msg) {
  if (msg) {
    inputEl.classList.add("is-invalid");
    inputEl.classList.remove("is-valid");
    errEl.textContent = msg;
    errEl.style.display = "block";
  } else {
    inputEl.classList.remove("is-invalid");
    inputEl.classList.add("is-valid");
    errEl.textContent = "";
    errEl.style.display = "none";
  }
}

const authShell = (title, sub, form, foot) =>
  pageHeader(title, sub) +
  wrap(`
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-5">
        <div class="panel auth-panel">
          ${form}
          <p class="auth-foot">${foot}</p>
        </div>
      </div>
    </div>`);

function loginPage(main) {
  const formHtml = `
    <form id="login-form" novalidate>
      <div id="login-alert" class="alert alert-danger d-none mb-3" role="alert"></div>

      <div class="mb-3">
        <label class="form-label" for="l-email">Email Address <span class="text-danger">*</span></label>
        <input class="form-control"
               id="l-email"
               name="email"
               type="email"
               placeholder="e.g. admin@esporthub.demo"
               autocomplete="username">
        <div class="invalid-feedback" id="l-email-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="l-phone">Phone Number <span class="text-danger">*</span></label>
        <input class="form-control"
               id="l-phone"
               name="phone"
               type="tel"
               inputmode="numeric"
               maxlength="10"
               placeholder="10-digit mobile number (e.g. 9876543210)"
               autocomplete="tel">
        <div class="invalid-feedback" id="l-phone-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="l-pass">Password <span class="text-danger">*</span></label>
        <input class="form-control"
               id="l-pass"
               name="password"
               type="password"
               placeholder="At least 8 chars with A-Z, 0-9, @#$"
               autocomplete="current-password">
        <div class="invalid-feedback" id="l-pass-err"></div>
      </div>

      <button class="btn btn-eh w-100 mt-2" type="submit">Log in</button>
    </form>
    <div class="demo-creds">
      <p>Demo accounts (click to auto-fill valid credentials):</p>
      <div class="d-flex gap-2 flex-wrap">
        <button class="btn btn-eh-outline btn-sm" data-fill="admin">Fill admin</button>
        <button class="btn btn-eh-outline btn-sm" data-fill="player">Fill player</button>
      </div>
    </div>`;

  const footHtml = `
    <a href="${routes.forgot()}">Forgot password?</a> ·
    New here? <a href="${routes.register()}">Create an account</a>`;

  main.innerHTML = authShell(
    "Login",
    "Welcome back. Pick up where you left off.",
    formHtml,
    footHtml,
  );

  const f = document.getElementById("login-form");
  const emailInput = document.getElementById("l-email");
  const phoneInput = document.getElementById("l-phone");
  const passInput = document.getElementById("l-pass");
  const emailErr = document.getElementById("l-email-err");
  const phoneErr = document.getElementById("l-phone-err");
  const passErr = document.getElementById("l-pass-err");
  const alertBox = document.getElementById("login-alert");

  // Real-time live validation on input
  emailInput.addEventListener("input", () => {
    if (emailInput.value.length > 0) {
      const res = JS_VALIDATORS.validateField("email", emailInput.value);
      setFieldError(emailInput, emailErr, res.error);
    } else {
      setFieldError(emailInput, emailErr, null);
    }
  });

  phoneInput.addEventListener("input", () => {
    if (phoneInput.value.length > 0) {
      const res = JS_VALIDATORS.validateField("phone", phoneInput.value);
      setFieldError(phoneInput, phoneErr, res.error);
    } else {
      setFieldError(phoneInput, phoneErr, null);
    }
  });

  passInput.addEventListener("input", () => {
    if (passInput.value.length > 0) {
      const res = JS_VALIDATORS.validateField("password", passInput.value);
      setFieldError(passInput, passErr, res.error);
    } else {
      setFieldError(passInput, passErr, null);
    }
  });

  // Demo autofill buttons
  main.querySelectorAll("[data-fill]").forEach((b) =>
    b.addEventListener("click", () => {
      const fillType = b.dataset.fill;
      const isPlayer = fillType === "player";
      const playerUser = loadData(KEYS.users, []).find(
        (u) => u.role === "player",
      );
      const e = isPlayer
        ? (playerUser?.email ?? "player@esporthub.demo")
        : "admin@esporthub.demo";
      const ph = isPlayer ? "9812345678" : "9876543210";
      const p = isPlayer ? "Player@123" : "Admin@123";

      emailInput.value = e;
      phoneInput.value = ph;
      passInput.value = p;

      setFieldError(emailInput, emailErr, null);
      setFieldError(phoneInput, phoneErr, null);
      setFieldError(passInput, passErr, null);
      alertBox.classList.add("d-none");
    }),
  );

  // Form submission with all 5 validations
  f.addEventListener("submit", (e) => {
    e.preventDefault();

    const emailVal = emailInput.value;
    const phoneVal = phoneInput.value;
    const passVal = passInput.value;

    const emailRes = JS_VALIDATORS.validateField("email", emailVal);
    const phoneRes = JS_VALIDATORS.validateField("phone", phoneVal);
    const passRes = JS_VALIDATORS.validateField("password", passVal);

    setFieldError(emailInput, emailErr, emailRes.error);
    setFieldError(phoneInput, phoneErr, phoneRes.error);
    setFieldError(passInput, passErr, passRes.error);

    // Check if all fields are empty
    const allEmpty = !emailVal.trim() && !phoneVal.trim() && !passVal;
    if (allEmpty) {
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-exclamation-triangle-fill fs-5" aria-hidden="true"></i>
          <div>
            <strong>Validation Error:</strong> All fields are required! Please fill in all fields.
          </div>
        </div>`;
      alertBox.classList.remove("d-none");
      return;
    }

    // Check specific validation failures
    if (!emailRes.ok || !phoneRes.ok || !passRes.ok) {
      const firstFail = !emailRes.ok
        ? emailRes
        : !phoneRes.ok
          ? phoneRes
          : passRes;
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-x-circle-fill fs-5" aria-hidden="true"></i>
          <div>
            <strong>Validation Error:</strong> ${firstFail.error}
          </div>
        </div>`;
      alertBox.classList.remove("d-none");
      return;
    }

    // Validations passed
    alertBox.classList.add("d-none");
    const r = login(emailVal, passVal);
    if (!r.ok) {
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-shield-lock-fill fs-5" aria-hidden="true"></i>
          <div>${esc(r.error)}</div>
        </div>`;
      alertBox.classList.remove("d-none");
      toast(r.error, "danger");
      return;
    }
    toast("Login successful! Redirecting...", "success");
    location.href = safeNext(getParam("next")) ?? homeFor(r.user.role);
  });
}

function registerPage(main) {
  const formHtml = `
    <form id="reg-user" novalidate>
      <div id="reg-alert" class="alert alert-danger d-none mb-3" role="alert"></div>

      <div class="mb-3">
        <label class="form-label" for="u-name">Full Name <span class="text-danger">*</span></label>
        <input class="form-control" id="u-name" name="name" placeholder="Your full name" autocomplete="name">
        <div class="invalid-feedback" id="u-name-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="u-email">Email Address <span class="text-danger">*</span></label>
        <input class="form-control" id="u-email" name="email" type="email" placeholder="name@domain.com" autocomplete="email">
        <div class="invalid-feedback" id="u-email-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="u-phone">Phone Number <span class="text-danger">*</span></label>
        <input class="form-control" id="u-phone" name="phone" type="tel" inputmode="numeric" maxlength="10" placeholder="10-digit phone number (e.g. 9876543210)">
        <div class="invalid-feedback" id="u-phone-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="u-pass">Password <span class="text-danger">*</span></label>
        <input class="form-control" id="u-pass" name="password" type="password" placeholder="At least 8 chars with uppercase, number & symbol" autocomplete="new-password">
        <div class="invalid-feedback" id="u-pass-err"></div>
      </div>

      <div class="mb-3">
        <label class="form-label" for="u-pass2">Confirm Password <span class="text-danger">*</span></label>
        <input class="form-control" id="u-pass2" name="confirmPassword" type="password" placeholder="Re-enter your password" autocomplete="new-password">
        <div class="invalid-feedback" id="u-pass2-err"></div>
      </div>

      <button class="btn btn-eh w-100" type="submit">Create account</button>
    </form>`;

  const footHtml = `Already registered? <a href="${routes.login()}">Log in</a>`;

  main.innerHTML = authShell(
    "Create account",
    "Join as a player and register your squad.",
    formHtml,
    footHtml,
  );

  const f = document.getElementById("reg-user");
  const nameInput = document.getElementById("u-name");
  const emailInput = document.getElementById("u-email");
  const phoneInput = document.getElementById("u-phone");
  const passInput = document.getElementById("u-pass");
  const pass2Input = document.getElementById("u-pass2");

  const nameErr = document.getElementById("u-name-err");
  const emailErr = document.getElementById("u-email-err");
  const phoneErr = document.getElementById("u-phone-err");
  const passErr = document.getElementById("u-pass-err");
  const pass2Err = document.getElementById("u-pass2-err");
  const alertBox = document.getElementById("reg-alert");

  // Real-time live validations
  nameInput.addEventListener("input", () => {
    const res = JS_VALIDATORS.validateField("name", nameInput.value);
    setFieldError(nameInput, nameErr, nameInput.value ? res.error : null);
  });
  emailInput.addEventListener("input", () => {
    const res = JS_VALIDATORS.validateField("email", emailInput.value);
    setFieldError(emailInput, emailErr, emailInput.value ? res.error : null);
  });
  phoneInput.addEventListener("input", () => {
    const res = JS_VALIDATORS.validateField("phone", phoneInput.value);
    setFieldError(phoneInput, phoneErr, phoneInput.value ? res.error : null);
  });
  passInput.addEventListener("input", () => {
    const res = JS_VALIDATORS.validateField("password", passInput.value);
    setFieldError(passInput, passErr, passInput.value ? res.error : null);
  });
  pass2Input.addEventListener("input", () => {
    if (pass2Input.value && pass2Input.value !== passInput.value) {
      setFieldError(pass2Input, pass2Err, "Passwords must match.");
    } else {
      setFieldError(pass2Input, pass2Err, null);
    }
  });

  f.addEventListener("submit", (e) => {
    e.preventDefault();

    const nameVal = nameInput.value;
    const emailVal = emailInput.value;
    const phoneVal = phoneInput.value;
    const passVal = passInput.value;
    const pass2Val = pass2Input.value;

    const nameRes = JS_VALIDATORS.validateField("name", nameVal);
    const emailRes = JS_VALIDATORS.validateField("email", emailVal);
    const phoneRes = JS_VALIDATORS.validateField("phone", phoneVal);
    const passRes = JS_VALIDATORS.validateField("password", passVal);

    setFieldError(nameInput, nameErr, nameRes.error);
    setFieldError(emailInput, emailErr, emailRes.error);
    setFieldError(phoneInput, phoneErr, phoneRes.error);
    setFieldError(passInput, passErr, passRes.error);

    const matchErr = !pass2Val
      ? "Confirm Password is required."
      : passVal !== pass2Val
        ? "Passwords must match."
        : null;
    setFieldError(pass2Input, pass2Err, matchErr);

    const allEmpty =
      !nameVal.trim() && !emailVal.trim() && !phoneVal.trim() && !passVal;
    if (allEmpty) {
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-exclamation-triangle-fill fs-5" aria-hidden="true"></i>
          <div>
            <strong>Validation Error:</strong> All fields are required! Please fill out all fields.
          </div>
        </div>`;
      alertBox.classList.remove("d-none");
      return;
    }

    if (
      !nameRes.ok ||
      !emailRes.ok ||
      !phoneRes.ok ||
      !passRes.ok ||
      matchErr
    ) {
      const firstFail = !nameRes.ok
        ? nameRes
        : !emailRes.ok
          ? emailRes
          : !phoneRes.ok
            ? phoneRes
            : !passRes.ok
              ? passRes
              : { error: matchErr };
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-x-circle-fill fs-5" aria-hidden="true"></i>
          <div>
            <strong>Validation Error:</strong> ${firstFail.error}
          </div>
        </div>`;
      alertBox.classList.remove("d-none");
      return;
    }

    alertBox.classList.add("d-none");
    const r = registerUser({
      name: nameVal,
      email: emailVal,
      password: passVal,
      phone: phoneVal,
    });
    if (!r.ok) {
      alertBox.className = "alert alert-danger mb-3";
      alertBox.innerHTML = `
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-shield-lock-fill fs-5" aria-hidden="true"></i>
          <div>${esc(r.error)}</div>
        </div>`;
      alertBox.classList.remove("d-none");
      toast(r.error, "danger");
      return;
    }
    login(r.user.email, passVal);
    location.href = routes.playerHome();
  });
}

function forgotPage(main) {
  const formHtml = `
    <form id="forgot" novalidate>
      ${field("f-email", "Email", 'type="email" required', "Enter a valid email address.")}
      <button class="btn btn-eh w-100" type="submit">Send reset link</button>
    </form>`;

  const footHtml = `<a href="${routes.login()}">Back to login</a>`;

  main.innerHTML = authShell(
    "Reset password",
    "Enter your email and we'll send reset steps.",
    formHtml,
    footHtml,
  );

  const f = document.getElementById("forgot");
  f.addEventListener("submit", (e) => {
    e.preventDefault();
    f.classList.add("was-validated");
    if (!f.checkValidity()) return;
    toast(
      "Demo mode: no email is sent. A real backend would send the reset link here.",
      "info",
    );
    f.reset();
    f.classList.remove("was-validated");
  });
}

const PAGES = {
  tournaments: tournamentsPage,
  "tournament-details": tournamentDetailsPage,
  registration: registrationPage,
  matches: matchesPage,
  "match-details": matchDetailsPage,
  leaderboard: leaderboardPage,
  teams: teamsPage,
  "team-details": teamDetailsPage,
  "player-profile": playerProfilePage,
  news: newsPage,
  about: aboutPage,
  contact: contactPage,
  login: loginPage,
  register: registerPage,
  "forgot-password": forgotPage,
};

export function render(key, { main }) {
  const fn = PAGES[key];
  if (!fn) throw new Error(`No renderer for public page "${key}"`);
  fn(main);
}
