// scoring.js — ALL scoring logic lives here. Nothing else may calculate points.
//
// Match score      = placement points + kill points + bonus
// Tournament total = sum of every completed match score (works for 4, 6 or 8 matches — it just loops)
//
// ⚠ PLACEHOLDER VALUES: the official tournament scoring system has not been supplied yet.
// Change DEFAULT_SCORING_RULES below (or edit the "scoringRules" record in storage) and the whole
// site recalculates. A tournament can also carry its own `scoringRules` object to override these.

export const DEFAULT_SCORING_RULES = {
  isPlaceholder: true,
  killPoints: 1,
  placementPoints: { 1: 10, 2: 6, 3: 5, 4: 4, 5: 3, 6: 2, 7: 1, 8: 1 }, // anything not listed = 0
  bonusPoints: 0, // reserved for rule-based bonuses; per-result `bonus` is added as-is
  // Tie-breakers are tried in order when total points are equal. Valid keys: see TIE_BREAKERS.
  tieBreakers: ["wins", "kills", "placementPoints"],
};

const TIE_BREAKERS = {
  wins: (s) => s.wins,
  kills: (s) => s.kills,
  placementPoints: (s) => s.placementPoints,
  killPoints: (s) => s.killPoints,
  bestMatch: (s) => Math.max(0, ...s.perMatch.map((m) => m.total)),
};

/** Points for ONE team in ONE match. `result` = { teamId, placement, kills, bonus } */
export function calculateMatchPoints(result, rules = DEFAULT_SCORING_RULES) {
  const placementPoints = result.placement
    ? (rules.placementPoints?.[result.placement] ?? 0)
    : 0;
  const killPoints = (Number(result.kills) || 0) * (rules.killPoints ?? 0);
  const bonus = Number(result.bonus) || 0;
  return {
    placementPoints,
    killPoints,
    bonus,
    total: placementPoints + killPoints + bonus,
  };
}

/** Totals for ONE team across all the matches passed in (pass completed matches only). */
export function calculateTournamentPoints(
  teamId,
  matches,
  rules = DEFAULT_SCORING_RULES,
) {
  const stats = {
    teamId,
    matches: 0,
    wins: 0,
    kills: 0,
    placementPoints: 0,
    killPoints: 0,
    bonus: 0,
    total: 0,
    perMatch: [],
  };
  for (const match of matches) {
    const result = match.results?.find((r) => r.teamId === teamId);
    if (!result) continue;
    const pts = calculateMatchPoints(result, rules);
    stats.matches += 1;
    stats.wins += result.placement === 1 ? 1 : 0;
    stats.kills += Number(result.kills) || 0;
    stats.placementPoints += pts.placementPoints;
    stats.killPoints += pts.killPoints;
    stats.bonus += pts.bonus;
    stats.total += pts.total;
    stats.perMatch.push({
      matchId: match.id,
      matchNumber: match.matchNumber,
      placement: result.placement,
      kills: result.kills,
      ...pts,
    });
  }
  return stats;
}

/** Ranked table for a set of matches. Returns [{ rank, teamId, ...stats }] */
export function generateLeaderboard(
  matches,
  teamIds,
  rules = DEFAULT_SCORING_RULES,
) {
  const rows = teamIds
    .map((id) => calculateTournamentPoints(id, matches, rules))
    .filter((r) => r.matches > 0);
  const order = rules.tieBreakers ?? DEFAULT_SCORING_RULES.tieBreakers;
  rows.sort((a, b) => {
    if (b.total !== a.total) return b.total - a.total;
    for (const key of order) {
      const fn = TIE_BREAKERS[key];
      if (!fn) continue;
      const diff = fn(b) - fn(a);
      if (diff) return diff;
    }
    return 0;
  });
  return rows.map((r, i) => ({ rank: i + 1, ...r }));
}
